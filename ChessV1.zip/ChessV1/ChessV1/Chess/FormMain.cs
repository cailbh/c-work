﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Chess
{
    //棋子枚举类型
    public enum Piece
    {
        无子 = 0,
        红车 = 1, 红马 = 2, 红相 = 3, 红士 = 4, 红帅 = 5, 红炮 = 6, 红卒 = 7,
        蓝车 = 8, 蓝马 = 9, 蓝象 = 10, 蓝士 = 11, 蓝将 = 12, 蓝炮 = 13, 蓝兵 = 14
    }

    //主窗口类
    public partial class FormMain : Form
    {
        //保存棋盘的所有棋子值
        private Piece[,] _chess = new Piece[11, 10];

        //保存键盘(细框)的左上角坐标
        private Point _leftTop = new Point(60, 60);

        //保存棋盘格子的行高和列宽
        private int _rowHeight = 60;
        private int _colWidth = 60;

        //保存棋子半径
        private int _pieceR = 29;

        //自定义类方法：绘制棋盘
        public void DrawBoard(Graphics g)
        {
            //绘制棋盘桌面
            Bitmap deskbmp = new Bitmap("desktop.jpg");
            g.DrawImage(deskbmp, new Point(0, 0));

            //绘制粗画笔和细画笔
            Pen thickPen = new Pen(Color.Black, 6);
            Pen thinPen = new Pen(Color.Black, 2);

            //绘制棋盘外围粗框
            int gap = (int)(_rowHeight * 0.15);
            g.DrawRectangle(thickPen, new Rectangle(_leftTop.X - gap, _leftTop.Y - gap, _colWidth * 8 + 2 * gap, _rowHeight * 9 + 2 * gap));

            //绘制棋盘十条横线
            for (int row = 1; row <= 10; row++)
            {
                g.DrawLine(thinPen, new Point(_leftTop.X , _leftTop.Y + _rowHeight * (row - 1)),
                                 new Point(_leftTop.X + 8 * _colWidth, _leftTop.Y + _rowHeight * (row - 1)));
            }

            //绘制棋盘九条竖线
            for (int col = 1; col <= 9; col++)
            {
                //绘制上半部分竖线
                g.DrawLine(thinPen, new Point(_leftTop.X + (col - 1) * _colWidth, _leftTop.Y ),
                                 new Point(_leftTop.X + (col - 1) * _colWidth, _leftTop.Y + _rowHeight * 4));
                //绘制下半部分竖线
                g.DrawLine(thinPen, new Point(_leftTop.X + (col - 1) * _colWidth, _leftTop.Y + _rowHeight * 5),
                                 new Point(_leftTop.X + (col - 1) * _colWidth, _leftTop.Y + _rowHeight * 9));
            }

            //绘制链接楚河汉界的短竖线
            g.DrawLine(thinPen, new Point(_leftTop.X, _leftTop.Y + _rowHeight * 4),
                              new Point(_leftTop.X, _leftTop.Y + _rowHeight * 5));
            g.DrawLine(thinPen, new Point(_leftTop.X + 8 * _colWidth, _leftTop.Y + _rowHeight * 4),
                              new Point(_leftTop.X + 8 * _colWidth, _leftTop.Y + _rowHeight * 5));

            //绘制上方九宫格交叉线
            g.DrawLine(thinPen, new Point(_leftTop.X + 3 * _colWidth, _leftTop.Y),
                              new Point(_leftTop.X + 5 * _colWidth, _leftTop.Y + _rowHeight * 2));
            g.DrawLine(thinPen, new Point(_leftTop.X + 5 * _colWidth, _leftTop.Y),
                              new Point(_leftTop.X + 3 * _colWidth, _leftTop.Y + _rowHeight * 2));
            //绘制下方九宫格交叉线
            g.DrawLine(thinPen, new Point(_leftTop.X + 3 * _colWidth, _leftTop.Y + _rowHeight * 7),
                              new Point(_leftTop.X + 5 * _colWidth, _leftTop.Y + _rowHeight * 9));
            g.DrawLine(thinPen, new Point(_leftTop.X + 5 * _colWidth, _leftTop.Y + _rowHeight * 7),
                              new Point(_leftTop.X + 3 * _colWidth, _leftTop.Y + _rowHeight * 9));

            //书写楚河汉界
            Font font1 = new Font("隶书", (float)(_rowHeight * 0.8), FontStyle.Regular, GraphicsUnit.Pixel);
            SolidBrush brush = new SolidBrush(Color.Black);
            g.DrawString("楚河", font1, brush, new Point(_leftTop.X + _colWidth, (int)(_leftTop.Y + _rowHeight * 4.1)));
            g.DrawString("汉界", font1, brush, new Point(_leftTop.X + _colWidth*5, (int)(_leftTop.Y + _rowHeight * 4.1)));

            //书写行的编号
            Font font2 = new Font("黑体", (float)(_rowHeight * 0.6), FontStyle.Regular, GraphicsUnit.Pixel);
            for (int row = 1; row <= 10; row++)
                g.DrawString(row.ToString(), font2, brush, new Point((int)(_leftTop.X + _colWidth * 8.6),
                                                                (int)(_leftTop.Y - _rowHeight * 0.4 + _rowHeight * (row - 1))));

            //书写列的编号
            string[] colNumber = new string[9] { "一", "二", "三", "四", "五", "六", "七", "八", "九" };
            Font font3 = new Font("黑体", (float)(_rowHeight * 0.5), FontStyle.Regular, GraphicsUnit.Pixel);
            for (int col = 1; col <= 9; col++)
            {
                g.DrawString(colNumber[col - 1], font3, brush, new Point((int)(_leftTop.X - _colWidth * 0.3 + _colWidth * (col - 1)),
                                                                    (int)(_leftTop.Y + _rowHeight * 9.6)));
            }

            //书写蓝方红方
            g.DrawString("蓝方", font3, brush, new Point(_leftTop.X + 8 * _colWidth + 95, _leftTop.Y + (int)(2.2 * _rowHeight)));
            g.DrawString("红方", font3, brush, new Point(_leftTop.X + 8 * _colWidth + 95, _leftTop.Y + (int)(6.4 * _rowHeight)));

            //绘制第三行炮兵营地标志
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 1, _leftTop.Y + _rowHeight * 2), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 7, _leftTop.Y + _rowHeight * 2), true, true);
            //绘制第八行炮兵营地标志
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 1, _leftTop.Y + _rowHeight * 7), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 7, _leftTop.Y + _rowHeight * 7), true, true);
            //绘制第四行兵营营地标志
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 0, _leftTop.Y + _rowHeight * 3), false, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 2, _leftTop.Y + _rowHeight * 3), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 4, _leftTop.Y + _rowHeight * 3), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 6, _leftTop.Y + _rowHeight * 3), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 8, _leftTop.Y + _rowHeight * 3), true, false);
            //绘制第七行兵营营地标志
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 0, _leftTop.Y + _rowHeight * 6), false, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 2, _leftTop.Y + _rowHeight * 6), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 4, _leftTop.Y + _rowHeight * 6), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 6, _leftTop.Y + _rowHeight * 6), true, true);
            DrawCampMark(g, new Point(_leftTop.X + _colWidth * 8, _leftTop.Y + _rowHeight * 6), true, false);
        }

        //自定义类方法：绘制营地标志
        public void DrawCampMark(Graphics g, Point center, Boolean drawLeft, Boolean drawRight)
        {
            //偏移量和线段长度
            int offset = (int)(_rowHeight * 0.08), length = (int)(_rowHeight * 0.16);
            //直角点坐标
            Point corner = new Point();
            //画笔对象
            Pen thinPen = new Pen(Color.Black, 1);

            //是否需要绘制左边标志
            if (drawLeft == true)
            {
                //绘制左上角直角边
                corner.X = center.X - offset;
                corner.Y = center.Y - offset;
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X - length, corner.Y));
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X, corner.Y - length));

                //绘制左下角直角边
                corner.X = center.X - offset;
                corner.Y = center.Y + offset;
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X - length, corner.Y));
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X, corner.Y + length));
            }

            //是否需要绘制右边标志
            if (drawRight == true)
            {
                //绘制右上角直角边
                corner.X = center.X + offset;
                corner.Y = center.Y - offset;
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X + length, corner.Y));
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X, corner.Y - length));

                //绘制右下角直角边
                corner.X = center.X + offset;
                corner.Y = center.Y + offset;
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X + length, corner.Y));
                g.DrawLine(thinPen, new Point(corner.X, corner.Y), new Point(corner.X, corner.Y + length));
            }
        }

        //自定义类方法：绘制棋子
        public void DrawPiece(Graphics g)
        {
            //逐行逐列绘制象棋棋子
            for (int row = 1; row <= 10; row++)
            {
                for (int col = 1; col <= 9; col++)
                {
                    //如果位置存在棋子
                    if (_chess[row, col] != Piece.无子)
                    {
                        //装载对应棋子位图
                        Bitmap pieceBmp = new Bitmap(_chess[row, col].ToString() + ".bmp");
                        //设置棋子透明色
                        pieceBmp.MakeTransparent(Color.White);
                        //在棋盘交点位置绘制棋子
                        g.DrawImage(pieceBmp, new Point(_leftTop.X + (col - 1) * _colWidth - _pieceR,
                                                     _leftTop.Y + (row - 1) * _rowHeight - _pieceR));
                    }
                }
            }
        }

        //自定义类方法：
        public bool ConvertPointToRowCol(Point p, out int row, out int col)
        {
            //获取与鼠标点击位置距离最近的棋盘交叉点的行号
            row = (p.Y - _leftTop.Y) / _rowHeight + 1;
            //如果鼠标点Y坐标超过棋盘行高的中线，则行号加一
            if (((p.Y - _leftTop.Y) % _rowHeight) >= _rowHeight / 2)
                row = row + 1;

            //获取与鼠标点击位置距离最近的棋盘交叉点的列号
            col = (p.X - _leftTop.X) / _colWidth + 1;
            //如果鼠标点X坐标超过棋盘列宽的中线，则列号加一
            if (((p.X - _leftTop.X) % _colWidth) >= _colWidth / 2)
                col = col + 1;

            //获取与鼠标点击位置距离最近的棋盘交叉点的坐标
            Point chessP = new Point();
            chessP.X = _leftTop.X + _colWidth * (col - 1);
            chessP.Y = _leftTop.Y + _rowHeight * (row - 1);

            //判断是否落在棋子半径之内，且在10行9列之中
            double dist = Math.Sqrt(Math.Pow(p.X - chessP.X, 2) + Math.Pow(p.Y - chessP.Y, 2));
            if ((dist <= 29) && (row <= 10) && (row >= 1) && (col <= 9) && (col >= 1))
            {
                //返回true，表示该点击为有效点击
                return true;
            }
            else
            {
                //把行号和列号设置为0，并返回false，表示该点击为无效点击
                row = 0; col = 0;
                return false;
            }
        }

        //构造方法
        public FormMain()
        {
            InitializeComponent();

            //根据分辨率设置棋盘行高列宽
            _rowHeight = Screen.PrimaryScreen.Bounds.Size.Height/14;
            _colWidth = _rowHeight;

            //设置象棋棋盘左上角坐标
            _leftTop.Y = 2 * _rowHeight;
            _leftTop.X = _leftTop.Y;

            //把象棋棋盘棋子数组初始化为“无子”
            for (int row = 1; row <= 10; row++)
                for (int col = 1; col <= 9; col++)
                    _chess[row, col] = Piece.无子;


        }

        //Paint事件响应方法
        private void FormMain_Paint(object sender, PaintEventArgs e)
        {

            //绘制棋盘
            DrawBoard(e.Graphics);

            //绘制棋子
            DrawPiece(e.Graphics);
        }

        private void MenuItemBegin_Click(object sender, EventArgs e)
        {
            //把象棋棋盘棋子数组初始化为“无子”
            for (int row = 1; row <= 10; row++)
                for (int col = 1; col <= 9; col++)
                    _chess[row, col] = Piece.无子;

            //初始化蓝方棋子
            _chess[1, 1] = Piece.蓝车; _chess[1, 2] = Piece.蓝马; _chess[1, 3] = Piece.蓝象;
            _chess[1, 4] = Piece.蓝士; _chess[1, 5] = Piece.蓝将; _chess[1, 6] = Piece.蓝士;
            _chess[1, 7] = Piece.蓝象; _chess[1, 8] = Piece.蓝马; _chess[1, 9] = Piece.蓝车;
            _chess[3, 2] = Piece.蓝炮; _chess[3, 8] = Piece.蓝炮;
            _chess[4, 1] = Piece.蓝兵; _chess[4, 3] = Piece.蓝兵; _chess[4, 5] = Piece.蓝兵;
            _chess[4, 7] = Piece.蓝兵; _chess[4, 9] = Piece.蓝兵;

            //初始化红方棋子
            _chess[10, 1] = Piece.红车; _chess[10, 2] = Piece.红马; _chess[10, 3] = Piece.红相;
            _chess[10, 4] = Piece.红士; _chess[10, 5] = Piece.红帅; _chess[10, 6] = Piece.红士;
            _chess[10, 7] = Piece.红相; _chess[10, 8] = Piece.红马; _chess[10, 9] = Piece.红车;
            _chess[8, 2] = Piece.红炮; _chess[8, 8] = Piece.红炮;
            _chess[7, 1] = Piece.红卒; _chess[7, 3] = Piece.红卒; _chess[7, 5] = Piece.红卒;
            _chess[7, 7] = Piece.红卒; _chess[7, 9] = Piece.红卒;

            //使窗口失效，并发送Paint消息，从而触发Paint事件响应方法重绘棋盘和棋子
            Invalidate();
        }
    }
}
