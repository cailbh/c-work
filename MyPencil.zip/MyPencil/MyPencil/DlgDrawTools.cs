﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyPencil
{
    public partial class DlgDrawTools : Form
    {
        public FormMain _formMain;
        public DlgDrawTools()
        {
            InitializeComponent();
        }

        private void buttonLine_Click(object sender, EventArgs e)
        {
            _formMain.DrawType = DrawType.Line;
        }

        private void buttonRectangle_Click(object sender, EventArgs e)
        {
            _formMain.DrawType = DrawType.Rectangle;
        }

        private void buttonCircle_Click(object sender, EventArgs e)
        {
            _formMain.DrawType = DrawType.Circle;
        }

        private void buttonSketch_Click(object sender, EventArgs e)
        {
            _formMain.DrawType = DrawType.Sketch;
        }

        private void buttonWidth_Click(object sender, EventArgs e)
        {
            _formMain.MenuItemWidth_Click(null, null);
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            _formMain.MenuItemColor_Click(null, null);
        }

        private void buttonUndo_Click(object sender, EventArgs e)
        {
            _formMain.MenuItemUndo_Click(null, null);
        }

        private void buttonQuit_Click(object sender, EventArgs e)
        {
            _formMain.menuStrip1.Visible = true;
            _formMain.toolStrip1.Visible = true;
            _formMain.statusStrip1.Visible = true;
            _formMain.FormBorderStyle = FormBorderStyle.Sizable;
            _formMain.WindowState = FormWindowState.Minimized;
            this.Close();
        }

        private void DlgDrawTools_FormClosed(object sender, FormClosedEventArgs e)
        {
            buttonQuit_Click(null, null);
        }

       

       
    }
}
