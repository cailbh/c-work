﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Drawing.Imaging;
using System.Threading;
using System.Runtime.InteropServices;
using System.Reflection;

namespace MyPencil
{
    public partial class FormMain : Form
    {
        private List<Shape> _listShape = new List<Shape>();
        private List<Shape> _listTempShape = new List<Shape>();
        private Shape _tempShape = null;
        private DrawType _drawType = DrawType.Line;

        public DrawType DrawType
        {
            get { return _drawType; }
            set { _drawType = value; }
        }
        private int _drawWidth = 10;
        private string _tempText = "";
        private Color _drawColor = Color.Red;
        private BufferedGraphicsContext _bufGraphCont = null;
        private BufferedGraphics _bufGraph = null;
        private string _fileName = "";
        private Boolean _saveFlag = false;
        private double _zoomRatio = 1;
        private Size _panelDrawInitSize = new Size(0, 0);
        private Bitmap _screenBmp = null;
        private Graphics _screenBmpGraphics = null;
        public struct KeyMSG
        {
            public int vkCode;
            public int scanCode;
            public int flags;
            public int time;
            public int dwExtraInfo;
        }
        public delegate int HookProc(int nCode, Int32 wParam, IntPtr lParam);
        static int hKeyboardHook = 0;
        HookProc KeyboardHookProcedure;
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern int SetWindowsHookEx(int idHook, HookProc Ipfn, IntPtr hlnstance, int threadld);
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern bool UnhookWindowsHookEx(int idHook);
        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern int CallNextHookEx(int idHook, int nCode, Int32 wParam, IntPtr lParam);
        private int KeyboardHookProc(int nCode, Int32 wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                KeyMSG m = (KeyMSG)Marshal.PtrToStructure(lParam, typeof(KeyMSG));
                if (m.flags == 0 && m.vkCode == (int)(Keys.F3))
                {
                    MenuItemScreenPen_Click(this, null);
                    return 1;
                }
                return 0;
            }
            return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
        }
        public void HookStart()
        {
            if (hKeyboardHook == 0)
            {
                KeyboardHookProcedure = new HookProc(KeyboardHookProc);
                hKeyboardHook = SetWindowsHookEx(13, KeyboardHookProcedure, Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]), 0);
                if (hKeyboardHook == 0)
                {
                    HookStop();
                    throw new Exception("SetWindowsHookEx failed.");

                }
            }
        }
        public void HookStop()
        {
            bool retKeyboard = true;
            if (hKeyboardHook != 0)
            {
                retKeyboard = UnhookWindowsHookEx(hKeyboardHook);
                hKeyboardHook = 0;
            }
            if (!(retKeyboard))
                throw new Exception("UnhookWindowsHookEx failed.");
        }

        public FormMain()
        {
            InitializeComponent();
            try
            {
                HookStart();
            }
            catch (Exception ex)
            {
                MessageBox.Show("钩子安装失败！提示信息：" + ex.Message);
            }
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            _bufGraphCont = BufferedGraphicsManager.Current;
            _bufGraph = _bufGraphCont.Allocate(panelDraw.CreateGraphics(), panelDraw.ClientRectangle);
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            _screenBmp = new Bitmap(screenWidth, screenHeight);
            _screenBmpGraphics = Graphics.FromImage(_screenBmp);
            _screenBmpGraphics.Clear(Color.White);
            _panelDrawInitSize.Width = panelDraw.Width;
            _panelDrawInitSize.Height = panelDraw.Height;
            MenuItemUndo.Enabled = false;
            toolStripButtonUndo.Enabled = false;
            MenuItemRedo.Enabled = false;
            toolStripButtonRedo.Enabled = false;
            Cursor penCur = new Cursor("pencil.cur");
            this.Cursor = penCur;
            menuStrip1.Cursor = Cursors.Arrow;
            toolStrip1.Cursor = Cursors.Arrow;
            statusStrip1.Cursor = Cursors.Arrow;
        }

        private void FormMain_MouseUp(object sender, MouseEventArgs e)
        {

            if (_drawType != DrawType.Stop)
            {
                if (_drawType == DrawType.Line)
                {
                    ((Line)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                }
                else if (_drawType == DrawType.Rectangle)
                {
                    ((Rectangle)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                }
                else if (_drawType == DrawType.Circle)
                {
                    ((Circle)_tempShape).R = (float)Math.Sqrt(Math.Pow(((int)(e.X / _zoomRatio) - ((Circle)_tempShape).PCenter.X), 2) + Math.Pow(((int)(e.Y / _zoomRatio) - ((Circle)_tempShape).PCenter.Y), 2));
                }
                else if (_drawType == DrawType.Sketch)
                {
                    ((Sketch)_tempShape).PointList.Add(new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio)));
                }
                _listShape.Add(_tempShape);
                _saveFlag = true;
                _listTempShape.Clear();
                MenuItemRedo.Enabled = false;
                toolStripButtonRedo.Enabled = false;
                MenuItemUndo.Enabled = true;
                toolStripButtonUndo.Enabled = true;
                _bufGraph.Graphics.Clear(Color.White);
                foreach (Shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                _bufGraph.Render(this.CreateGraphics());
            }

        }

        private void FormMain_MouseDown(object sender, MouseEventArgs e)
        {
            if (_drawType != DrawType.Stop)
            {
                if (_drawType == DrawType.Line)
                {
                    _tempShape = new Line();
                    ((Line)_tempShape).P1 = new Point((int)(e.X/_zoomRatio),(int)(e.Y/_zoomRatio));
                }
                else if (_drawType == DrawType.Rectangle)
                {
                    _tempShape = new Rectangle();
                    ((Rectangle)_tempShape).P1 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                }
                else if (_drawType == DrawType.Circle)
                {
                    _tempShape = new Circle();
                    ((Circle)_tempShape).PCenter = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                }
                else if (_drawType == DrawType.Sketch)
                {
                    _tempShape = new Sketch();
                    ((Sketch)_tempShape).PointList.Add(new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio)));
                }
                _tempShape.PenWidth = _drawWidth;
                _tempShape.PenColor = _drawColor;
            }

        }

        private void FormMain_Paint(object sender, PaintEventArgs e)
        {
            _bufGraph.Graphics.Clear(Color.White);
            foreach (Shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
            _bufGraph.Render(this.CreateGraphics());
        }

        private void MenuItemLine_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Line;
        }

        private void MenuItemRectangle_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Rectangle;
        }

        private void MenuItemCircle_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Circle;
        }

        private void MenuItemSketch_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Sketch;
        }

        private void MenuItemStop_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Stop;
        }

        private void FormMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (_drawType != DrawType.Stop)
                {
                    _bufGraph.Graphics.Clear(Color.White);
                    foreach (Shape shape in _listShape)
                        shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                    if (_drawType == DrawType.Line)
                    {
                        ((Line)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                        
                        StatusLabelMousePosition.Text = "直线长度：" + (int)Math.Sqrt(Math.Pow(((Line)_tempShape).P2.X - ((Line)_tempShape).P1.X, 2) + Math.Pow(((Line)_tempShape).P2.Y - ((Line)_tempShape).P1.Y, 2));
                    }
                    else if (_drawType == DrawType.Rectangle)
                    {
                        ((Rectangle)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                       
                        StatusLabelMousePosition.Text = "矩形长：" + (int)Math.Abs(((Rectangle)_tempShape).P2.X - ((Rectangle)_tempShape).P1.X)
                     + "，矩形宽：" + Math.Abs(((Rectangle)_tempShape).P2.Y - ((Rectangle)_tempShape).P1.Y);
                    }
                    else if (_drawType == DrawType.Circle)
                    {
                        ((Circle)_tempShape).R = (float)Math.Sqrt(Math.Pow(((int)(e.X / _zoomRatio) - ((Circle)_tempShape).PCenter.X), 2) + Math.Pow(((int)(e.Y / _zoomRatio) - ((Circle)_tempShape).PCenter.Y), 2));
                        
                        StatusLabelMousePosition.Text = "圆半径：" + (int)((Circle)_tempShape).R;
                    }
                    else if (_drawType == DrawType.Sketch)
                    {
                        ((Sketch)_tempShape).PointList.Add(new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio)));
                        
                        StatusLabelMousePosition.Text ="线段结束位置：x=" + e.X + "，y=" + e.Y;
                    }
                    _tempShape.Draw(_bufGraph.Graphics, DashStyle.Dash, _zoomRatio);
                    _bufGraph.Render(this.CreateGraphics());
                    _tempText = StatusLabelMousePosition.Text;
                }
            }
            else
                StatusLabelMousePosition.Text = _tempText + "  鼠标：x=" + e.X + "，y=" + e.Y;
        }

        public void MenuItemWidth_Click(object sender, EventArgs e)
        {
            DlgPenWidth dlgPenWidth = new DlgPenWidth();
            dlgPenWidth._PenWidth = _drawWidth;
            if (dlgPenWidth.ShowDialog(this) == DialogResult.OK)
            {
                _drawWidth = dlgPenWidth._PenWidth;
            }
        }

        public void MenuItemColor_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = _drawColor;
            if (colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _drawColor = colorDialog1.Color;
            }
        }

        public void MenuItemUndo_Click(object sender, EventArgs e)
        {
            if (_listShape.Count != 0)
            {
                _listTempShape.Add(_listShape[_listShape.Count - 1]);
                _listShape.RemoveAt(_listShape.Count - 1);
                _bufGraph.Graphics.Clear(Color.White);
                _bufGraph.Graphics.DrawImage(_screenBmp, new Point(0, 0));
                foreach (Shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());
                if (_listShape.Count == 0)
                {
                    MenuItemUndo.Enabled = false;
                    toolStripButtonUndo.Enabled = false;
                }
                MenuItemRedo.Enabled = true;
                toolStripButtonRedo.Enabled = true;
                _saveFlag = true;
            }
        }

        private void MenuItemRedo_Click(object sender, EventArgs e)
        {
            if (_listTempShape.Count != 0)
            {
                _listShape.Add(_listTempShape[_listTempShape.Count - 1]);
                _listTempShape.RemoveAt(_listTempShape.Count - 1);
                _bufGraph.Graphics.Clear(Color.White);
                foreach (Shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());
                if (_listTempShape.Count == 0)
                {
                    MenuItemRedo.Enabled = false;
                    toolStripButtonRedo.Enabled = false;
                }
                MenuItemUndo.Enabled = true;
                toolStripButtonUndo.Enabled = true;
                _saveFlag = true;
            }
        }

        private void toolStripMenuItem1px_Click(object sender, EventArgs e)
        {
            _drawWidth = 1;
        }

        private void toolStripMenuItem2px_Click(object sender, EventArgs e)
        {
            _drawWidth = 2;
        }

        private void toolStripMenuItem4px_Click(object sender, EventArgs e)
        {
            _drawWidth = 4;
        }

        private void toolStripMenuItem8px_Click(object sender, EventArgs e)
        {
            _drawWidth = 8;
        }

        private void MenuItemBlack_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Black;
        }

        private void MenuItemRed_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Red;
        }

        private void MenuItemBlue_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Blue;
        }

        private void MenuItemGreen_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Green;
        }

        private void MenuItemYellow_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Yellow;
        }

        private void MenuItemNew_Click(object sender, EventArgs e)
        {
            if (_saveFlag == true)
            {
                if (MessageBox.Show("图形已经改变，你需要保存吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    MenuItemSave_Click(null, null);
                }
            }
            _listShape.Clear();
            _listTempShape.Clear();
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Render(panelDraw.CreateGraphics());
            _fileName = "";
            this.Text = "画笔-无标题";
            _saveFlag = false;
            MenuItemRedo.Enabled = false;
            toolStripButtonRedo.Enabled = false;
            MenuItemUndo.Enabled = false;
            toolStripButtonUndo.Enabled = false;

        }

        private void MenuItemOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                MenuItemNew_Click(null, null);
                _fileName = openFileDialog1.FileName;
                this.Text = "画笔-" + _fileName;
                FileStream fs = new FileStream(_fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                int shapeCount = br.ReadInt32();
                for (int i = 0; i < shapeCount; i++)
                {
                    string ShapeType = br.ReadString();
                    if (ShapeType == "Pencil.Line")
                    {
                        Line shape = new Line();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else if (ShapeType == "Pencil.Rectangle")
                    {
                        Rectangle shape = new Rectangle();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else if (ShapeType == "Pencil.Circle")
                    {
                        Circle shape = new Circle();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else if (ShapeType == "Pencil.Sketch")
                    {
                        Sketch shape = new Sketch();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else
                        MessageBox.Show("图元类型错误。", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                br.Close();
                fs.Close();
                _saveFlag = false;
                _bufGraph.Graphics.Clear(Color.White);
                foreach (Shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());
            }
        }

        private void MenuItemSave_Click(object sender, EventArgs e)
        {
            if (_fileName == "")
            {
                if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
                {
                    _fileName = saveFileDialog1.FileName;
                    this.Text = "画笔-" + _fileName;
                }
                else
                    return;
            }
            FileStream fs = new FileStream(_fileName, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(_listShape.Count);
            foreach (Shape tempShape in _listShape)
            {
                bw.Write(tempShape.GetType().ToString());
                tempShape.Write(bw);
            }
            bw.Close();
            fs.Close();
            _saveFlag = false;
        }

        private void MenuItemSaveAs_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _fileName = saveFileDialog1.FileName;
                this.Text = "画笔-" + _fileName;
                FileStream fs = new FileStream(_fileName, FileMode.Create);
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(_listShape.Count);
                foreach (Shape tempShape in _listShape)
                {
                    bw.Write(tempShape.GetType().ToString());
                    tempShape.Write(bw);
                }
                bw.Close();
                fs.Close();
                _saveFlag = false;
            }
        }

        private void MenuItemSaveAsPic_Click(object sender, EventArgs e)
        {
            if (saveFileDialog2.ShowDialog(this) == DialogResult.OK)
            {
                Bitmap bitmap=new Bitmap(this.ClientRectangle.Width,this.ClientRectangle.Height);
                Graphics gBitmap = Graphics.FromImage(bitmap);
                _bufGraph.Render(gBitmap);
                string extension = System.IO.Path.GetExtension(saveFileDialog2.FileName);
                if(extension==".jpg")
                    bitmap.Save(saveFileDialog2.FileName,ImageFormat.Jpeg);
                else if(extension==".gif")
                    bitmap.Save(saveFileDialog2.FileName,ImageFormat.Gif);
                else if(extension==".bmp")
                    bitmap.Save(saveFileDialog2.FileName,ImageFormat.Bmp);
                else
                    MessageBox.Show("对不起，暂不支持该图片格式。",extension,MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void MenuItemClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_saveFlag == true)
            {
                if (MessageBox.Show("图形已经改变，你需要保存吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    MenuItemSave_Click(null, null);
                }
            }
        }

        private void panelDraw_MouseDown(object sender, MouseEventArgs e)
        {
            if (_drawType != DrawType.Stop)
            {
                if (_drawType == DrawType.Line)
                {
                    _tempShape = new Line();
                    ((Line)_tempShape).P1 = new Point(e.X, e.Y);
                }
                else if (_drawType == DrawType.Rectangle)
                {
                    _tempShape = new Rectangle();
                    ((Rectangle)_tempShape).P1 = new Point(e.X, e.Y);
                }
                else if (_drawType == DrawType.Circle)
                {
                    _tempShape = new Circle();
                    ((Circle)_tempShape).PCenter = new Point(e.X, e.Y);
                }
                else if (_drawType == DrawType.Sketch)
                {
                    _tempShape = new Sketch();
                    ((Sketch)_tempShape).PointList.Add(new Point(e.X, e.Y));
                }
                _tempShape.PenWidth = _drawWidth;
                _tempShape.PenColor = _drawColor;
            }
        }

        private void panelDraw_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (_drawType != DrawType.Stop)
                {
                    _bufGraph.Graphics.Clear(Color.White);
                    _bufGraph.Graphics.DrawImage(_screenBmp, new Point(0, 0));
                    foreach (Shape shape in _listShape)
                        shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                    if (_drawType == DrawType.Line)
                    {
                        ((Line)_tempShape).P2 = e.Location;
                        StatusLabelMousePosition.Text = "直线长度：" + (int)Math.Sqrt(Math.Pow(((Line)_tempShape).P2.X - ((Line)_tempShape).P1.X, 2) + Math.Pow(((Line)_tempShape).P2.Y - ((Line)_tempShape).P1.Y, 2));
                    }
                    else if (_drawType == DrawType.Rectangle)
                    {
                        ((Rectangle)_tempShape).P2 = e.Location;
                        StatusLabelMousePosition.Text = "矩形长：" + (int)Math.Abs(((Rectangle)_tempShape).P2.X - ((Rectangle)_tempShape).P1.X)
                     + "，矩形宽：" + Math.Abs(((Rectangle)_tempShape).P2.Y - ((Rectangle)_tempShape).P1.Y);
                    }
                    else if (_drawType == DrawType.Circle)
                    {
                        ((Circle)_tempShape).R = (float)Math.Sqrt(Math.Pow((e.X - ((Circle)_tempShape).PCenter.X), 2) + Math.Pow((e.Y - ((Circle)_tempShape).PCenter.Y), 2));
                        StatusLabelMousePosition.Text = "圆半径：" + (int)((Circle)_tempShape).R;
                    }
                    else if (_drawType == DrawType.Sketch)
                    {
                        ((Sketch)_tempShape).PointList.Add(e.Location);
                        StatusLabelMousePosition.Text = "线段结束位置：x=" + e.X + "，y=" + e.Y;
                    }
                    if(_drawType == DrawType.Sketch)
                        _tempShape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
                    else
                        _tempShape.Draw(_bufGraph.Graphics, DashStyle.Dash, _zoomRatio);
                    _bufGraph.Render(panelDraw.CreateGraphics());
                    _tempText = StatusLabelMousePosition.Text;
                }
            }
            else
                StatusLabelMousePosition.Text = _tempText + "  鼠标：x=" + e.X + "，y=" + e.Y;
        }

        private void panelDraw_MouseUp(object sender, MouseEventArgs e)
        {
            if (_drawType != DrawType.Stop)
            {
                if (_drawType == DrawType.Line)
                {
                    ((Line)_tempShape).P2 = new Point(e.X, e.Y);
                }
                else if (_drawType == DrawType.Rectangle)
                {
                    ((Rectangle)_tempShape).P2 = new Point(e.X, e.Y);
                }
                else if (_drawType == DrawType.Circle)
                {
                    ((Circle)_tempShape).R = (float)Math.Sqrt(Math.Pow((e.X - ((Circle)_tempShape).PCenter.X), 2) + Math.Pow((e.Y - ((Circle)_tempShape).PCenter.Y), 2));
                }
                else if (_drawType == DrawType.Sketch)
                {
                    ((Sketch)_tempShape).PointList.Add(new Point(e.X, e.Y));
                }
                _listShape.Add(_tempShape);
                _saveFlag = true;
                _listTempShape.Clear();
                MenuItemRedo.Enabled = false;
                toolStripButtonRedo.Enabled = false;
                MenuItemUndo.Enabled = true;
                toolStripButtonUndo.Enabled = true;
                _bufGraph.Graphics.Clear(Color.White);
                _bufGraph.Graphics.DrawImage(_screenBmp, new Point(0, 0));
                foreach (Shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());
            }
        }

        private void panelDraw_Paint(object sender, PaintEventArgs e)
        {
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Graphics.DrawImage(_screenBmp, new Point(0, 0));
            foreach (Shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
            _bufGraph.Render(panelDraw.CreateGraphics());
        }

        private void MenuItemZoomIn_Click(object sender, EventArgs e)
        {
            _zoomRatio = _zoomRatio * 1.1;
            panelDraw.Width = (int)(_panelDrawInitSize.Width * _zoomRatio);
            panelDraw.Height = (int)(_panelDrawInitSize.Height * _zoomRatio);
            _bufGraph = _bufGraphCont.Allocate(panelDraw.CreateGraphics(), panelDraw.ClientRectangle);
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            foreach (Shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
            _bufGraph.Render(panelDraw.CreateGraphics());
        }

        private void MenuItemZoomOut_Click(object sender, EventArgs e)
        {
            _zoomRatio = _zoomRatio * 0.9;
            panelDraw.Width = (int)(_panelDrawInitSize.Width * _zoomRatio);
            panelDraw.Height = (int)(_panelDrawInitSize.Height * _zoomRatio);
            _bufGraph = _bufGraphCont.Allocate(panelDraw.CreateGraphics(), panelDraw.ClientRectangle);
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            foreach (Shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
            _bufGraph.Render(panelDraw.CreateGraphics());
        }

        private void MenuItemScreenPen_Click(object sender, EventArgs e)
        {
            if (this.FormBorderStyle != FormBorderStyle.None)
            {
                this.WindowState = FormWindowState.Minimized;
                menuStrip1.Visible = false;
                toolStrip1.Visible = false;
                statusStrip1.Visible = false;
                this.FormBorderStyle = FormBorderStyle.None;
                Thread.Sleep(300);
                int screenWidth = Screen.PrimaryScreen.Bounds.Width;
                int screenHeight = Screen.PrimaryScreen.Bounds.Height;
                _screenBmpGraphics.CopyFromScreen(0, 0, 0, 0, new Size(screenWidth, screenHeight));
                panelDraw.Width = screenWidth;
                panelDraw.Height = screenHeight;
                _zoomRatio = 1;
                _panelDrawInitSize = new Size(panelDraw.Width, panelDraw.Height);
                _bufGraph = _bufGraphCont.Allocate(panelDraw.CreateGraphics(), panelDraw.ClientRectangle);
                _bufGraph.Graphics.Clear(Color.White);
                _bufGraph.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                _bufGraph.Graphics.DrawImage(_screenBmp, new Point(0, 0));
                _bufGraph.Render(panelDraw.CreateGraphics());
                this.WindowState = FormWindowState.Maximized;
                DlgDrawTools myDlgDrawTools = new DlgDrawTools();
                myDlgDrawTools._formMain = this;
                myDlgDrawTools.Show();
            }
        }


    }
}
