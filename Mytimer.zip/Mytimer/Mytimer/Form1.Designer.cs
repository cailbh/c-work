﻿namespace Mytimer
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelHour = new System.Windows.Forms.Label();
            this.labelColon2 = new System.Windows.Forms.Label();
            this.labelSecond = new System.Windows.Forms.Label();
            this.labelColon1 = new System.Windows.Forms.Label();
            this.labelMinute = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.buttonpause = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.labelmessage = new System.Windows.Forms.Label();
            this.textBoxsecondcount = new System.Windows.Forms.TextBox();
            this.pictureHour1 = new System.Windows.Forms.PictureBox();
            this.pictureHour2 = new System.Windows.Forms.PictureBox();
            this.pictureDot1 = new System.Windows.Forms.PictureBox();
            this.pictureMinute1 = new System.Windows.Forms.PictureBox();
            this.pictureMinute2 = new System.Windows.Forms.PictureBox();
            this.pictureDot2 = new System.Windows.Forms.PictureBox();
            this.pictureSecond1 = new System.Windows.Forms.PictureBox();
            this.pictureSecond2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHour1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHour2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMinute1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMinute2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSecond1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSecond2)).BeginInit();
            this.SuspendLayout();
            // 
            // labelHour
            // 
            this.labelHour.AutoSize = true;
            this.labelHour.Font = new System.Drawing.Font("幼圆", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelHour.Location = new System.Drawing.Point(17, 122);
            this.labelHour.Name = "labelHour";
            this.labelHour.Size = new System.Drawing.Size(82, 56);
            this.labelHour.TabIndex = 0;
            this.labelHour.Text = "00";
            // 
            // labelColon2
            // 
            this.labelColon2.AutoSize = true;
            this.labelColon2.Font = new System.Drawing.Font("幼圆", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelColon2.Location = new System.Drawing.Point(249, 122);
            this.labelColon2.Name = "labelColon2";
            this.labelColon2.Size = new System.Drawing.Size(53, 56);
            this.labelColon2.TabIndex = 0;
            this.labelColon2.Text = ":";
            // 
            // labelSecond
            // 
            this.labelSecond.AutoSize = true;
            this.labelSecond.Font = new System.Drawing.Font("幼圆", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelSecond.Location = new System.Drawing.Point(307, 122);
            this.labelSecond.Name = "labelSecond";
            this.labelSecond.Size = new System.Drawing.Size(140, 56);
            this.labelSecond.TabIndex = 0;
            this.labelSecond.Text = "00.0";
            // 
            // labelColon1
            // 
            this.labelColon1.AutoSize = true;
            this.labelColon1.Font = new System.Drawing.Font("幼圆", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelColon1.Location = new System.Drawing.Point(104, 122);
            this.labelColon1.Name = "labelColon1";
            this.labelColon1.Size = new System.Drawing.Size(53, 56);
            this.labelColon1.TabIndex = 0;
            this.labelColon1.Text = ":";
            // 
            // labelMinute
            // 
            this.labelMinute.AutoSize = true;
            this.labelMinute.Font = new System.Drawing.Font("幼圆", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelMinute.Location = new System.Drawing.Point(162, 122);
            this.labelMinute.Name = "labelMinute";
            this.labelMinute.Size = new System.Drawing.Size(82, 56);
            this.labelMinute.TabIndex = 0;
            this.labelMinute.Text = "00";
            // 
            // buttonStart
            // 
            this.buttonStart.Font = new System.Drawing.Font("华文琥珀", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonStart.Location = new System.Drawing.Point(26, 207);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(88, 54);
            this.buttonStart.TabIndex = 1;
            this.buttonStart.Text = "开始";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Font = new System.Drawing.Font("华文琥珀", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonStop.Location = new System.Drawing.Point(364, 207);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(88, 54);
            this.buttonStop.TabIndex = 1;
            this.buttonStop.Text = "停止";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // buttonpause
            // 
            this.buttonpause.Font = new System.Drawing.Font("华文琥珀", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonpause.Location = new System.Drawing.Point(195, 207);
            this.buttonpause.Name = "buttonpause";
            this.buttonpause.Size = new System.Drawing.Size(88, 54);
            this.buttonpause.TabIndex = 1;
            this.buttonpause.Text = "暂停";
            this.buttonpause.UseVisualStyleBackColor = true;
            this.buttonpause.Click += new System.EventHandler(this.buttonpause_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // labelmessage
            // 
            this.labelmessage.AutoSize = true;
            this.labelmessage.Font = new System.Drawing.Font("幼圆", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelmessage.Location = new System.Drawing.Point(156, 47);
            this.labelmessage.Name = "labelmessage";
            this.labelmessage.Size = new System.Drawing.Size(291, 48);
            this.labelmessage.TabIndex = 2;
            this.labelmessage.Text = "秒   倒计时";
            this.labelmessage.UseMnemonic = false;
            // 
            // textBoxsecondcount
            // 
            this.textBoxsecondcount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.textBoxsecondcount.Font = new System.Drawing.Font("幼圆", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxsecondcount.Location = new System.Drawing.Point(71, 61);
            this.textBoxsecondcount.Name = "textBoxsecondcount";
            this.textBoxsecondcount.Size = new System.Drawing.Size(60, 34);
            this.textBoxsecondcount.TabIndex = 3;
            this.textBoxsecondcount.TextChanged += new System.EventHandler(this.textBoxsecondcount_TextChanged);
            // 
            // pictureHour1
            // 
            this.pictureHour1.Image = global::Mytimer.Properties.Resources._0;
            this.pictureHour1.Location = new System.Drawing.Point(53, 308);
            this.pictureHour1.Name = "pictureHour1";
            this.pictureHour1.Size = new System.Drawing.Size(30, 48);
            this.pictureHour1.TabIndex = 4;
            this.pictureHour1.TabStop = false;
            // 
            // pictureHour2
            // 
            this.pictureHour2.Image = global::Mytimer.Properties.Resources._0;
            this.pictureHour2.Location = new System.Drawing.Point(77, 308);
            this.pictureHour2.Name = "pictureHour2";
            this.pictureHour2.Size = new System.Drawing.Size(30, 48);
            this.pictureHour2.TabIndex = 4;
            this.pictureHour2.TabStop = false;
            // 
            // pictureDot1
            // 
            this.pictureDot1.Image = global::Mytimer.Properties.Resources._0;
            this.pictureDot1.Location = new System.Drawing.Point(147, 308);
            this.pictureDot1.Name = "pictureDot1";
            this.pictureDot1.Size = new System.Drawing.Size(30, 48);
            this.pictureDot1.TabIndex = 4;
            this.pictureDot1.TabStop = false;
            // 
            // pictureMinute1
            // 
            this.pictureMinute1.Image = global::Mytimer.Properties.Resources._0;
            this.pictureMinute1.Location = new System.Drawing.Point(217, 308);
            this.pictureMinute1.Name = "pictureMinute1";
            this.pictureMinute1.Size = new System.Drawing.Size(30, 48);
            this.pictureMinute1.TabIndex = 4;
            this.pictureMinute1.TabStop = false;
            // 
            // pictureMinute2
            // 
            this.pictureMinute2.Image = global::Mytimer.Properties.Resources._0;
            this.pictureMinute2.Location = new System.Drawing.Point(242, 308);
            this.pictureMinute2.Name = "pictureMinute2";
            this.pictureMinute2.Size = new System.Drawing.Size(30, 48);
            this.pictureMinute2.TabIndex = 4;
            this.pictureMinute2.TabStop = false;
            // 
            // pictureDot2
            // 
            this.pictureDot2.Image = global::Mytimer.Properties.Resources._0;
            this.pictureDot2.Location = new System.Drawing.Point(314, 308);
            this.pictureDot2.Name = "pictureDot2";
            this.pictureDot2.Size = new System.Drawing.Size(30, 48);
            this.pictureDot2.TabIndex = 4;
            this.pictureDot2.TabStop = false;
            // 
            // pictureSecond1
            // 
            this.pictureSecond1.Image = global::Mytimer.Properties.Resources._0;
            this.pictureSecond1.Location = new System.Drawing.Point(386, 308);
            this.pictureSecond1.Name = "pictureSecond1";
            this.pictureSecond1.Size = new System.Drawing.Size(30, 48);
            this.pictureSecond1.TabIndex = 4;
            this.pictureSecond1.TabStop = false;
            // 
            // pictureSecond2
            // 
            this.pictureSecond2.Image = global::Mytimer.Properties.Resources._0;
            this.pictureSecond2.Location = new System.Drawing.Point(410, 308);
            this.pictureSecond2.Name = "pictureSecond2";
            this.pictureSecond2.Size = new System.Drawing.Size(30, 48);
            this.pictureSecond2.TabIndex = 4;
            this.pictureSecond2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 471);
            this.Controls.Add(this.pictureSecond2);
            this.Controls.Add(this.pictureSecond1);
            this.Controls.Add(this.pictureDot2);
            this.Controls.Add(this.pictureMinute2);
            this.Controls.Add(this.pictureMinute1);
            this.Controls.Add(this.pictureDot1);
            this.Controls.Add(this.pictureHour2);
            this.Controls.Add(this.pictureHour1);
            this.Controls.Add(this.textBoxsecondcount);
            this.Controls.Add(this.labelmessage);
            this.Controls.Add(this.buttonpause);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.labelSecond);
            this.Controls.Add(this.labelMinute);
            this.Controls.Add(this.labelColon2);
            this.Controls.Add(this.labelColon1);
            this.Controls.Add(this.labelHour);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "我的计时器";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Move += new System.EventHandler(this.Form1_Move);
            ((System.ComponentModel.ISupportInitialize)(this.pictureHour1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHour2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMinute1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMinute2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSecond1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureSecond2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelHour;
        private System.Windows.Forms.Label labelColon2;
        private System.Windows.Forms.Label labelSecond;
        private System.Windows.Forms.Label labelColon1;
        private System.Windows.Forms.Label labelMinute;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonpause;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label labelmessage;
        private System.Windows.Forms.TextBox textBoxsecondcount;
        private System.Windows.Forms.PictureBox pictureHour1;
        private System.Windows.Forms.PictureBox pictureHour2;
        private System.Windows.Forms.PictureBox pictureDot1;
        private System.Windows.Forms.PictureBox pictureMinute1;
        private System.Windows.Forms.PictureBox pictureMinute2;
        private System.Windows.Forms.PictureBox pictureDot2;
        private System.Windows.Forms.PictureBox pictureSecond1;
        private System.Windows.Forms.PictureBox pictureSecond2;
    }
}

