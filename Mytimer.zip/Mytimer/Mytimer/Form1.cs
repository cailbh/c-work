﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mytimer
{
    public partial class Form1 : Form
    {
        private int _nowSecond = 0;
        private int _jage = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            _nowSecond = 0;
            timer2.Enabled = true;
            timer1.Enabled = true;
            labelHour.Text = "00";
            labelMinute.Text = "00";
            labelSecond.Text = "00";
            labelColon1.Visible = true;
            labelColon1.Visible = true;
            buttonStart.Enabled = false;
            buttonpause.Enabled = true;
            buttonStop.Enabled = true;
            buttonpause.Text = "暂停";
            if (_jage == 0)
            {
                _nowSecond = Convert.ToInt32(textBoxsecondcount.Text);
                _nowSecond = _nowSecond * 10;
            }
        }

        private void buttonpause_Click(object sender, EventArgs e)
        {
            if (buttonpause.Text == "暂停")
            {
                timer2.Enabled = false;
                timer1.Enabled = false;
                buttonpause.Text = "继续";
            }
            else
            {
                timer2.Enabled = true;
                timer1.Enabled = true;
                buttonpause.Text = "暂停";
            }
            
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            _nowSecond = 0;
            timer1.Enabled = false;
            buttonStart.Enabled = true;
            buttonpause.Enabled = false;
            buttonpause.Text = "暂停";
            labelColon1.Visible = true;
            labelColon2.Visible = true;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            if (_jage == 1)
            {
                _nowSecond++;
                int hour = _nowSecond / 36000;
                int minute = (_nowSecond % 36000) / 600;
                double second = (_nowSecond % 36000) % 600 / 10.0;
                if (hour <= 9)
                    labelHour.Text = "0" + hour.ToString();
                else
                    labelHour.Text = hour.ToString();
                if (minute <= 9)
                    labelMinute.Text = "0" + minute.ToString();
                else
                    labelMinute.Text = minute.ToString();
                if (second <= 10)
                    labelSecond.Text = "0" + second.ToString();
                else

                    labelSecond.Text = second.ToString();
            }
            else
            {
                _nowSecond--;
                int hour = _nowSecond / 36000;
                int minute = (_nowSecond % 36000) / 600;
                double second = (_nowSecond % 36000) % 600 / 10.0;
                if (hour <= 9)
                    labelHour.Text = "0" + hour.ToString();
                else
                    labelHour.Text = hour.ToString();
                if (minute <= 9)
                    labelMinute.Text = "0" + minute.ToString();
                else
                    labelMinute.Text = minute.ToString();
                if (second <= 10)
                    labelSecond.Text = "0" + second.ToString();
                else

                    labelSecond.Text = second.ToString();
                if (_nowSecond == 0)
                {
                    timer1.Enabled = false;
                    timer2.Enabled = false;
                    MessageBox.Show("午时已到");
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (labelColon1.Visible == true)
            {
                labelColon1.Visible = false;
                labelColon2.Visible = false;
            }
            else
            {
                labelColon1.Visible = true;
                labelColon2.Visible = true;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            buttonStart.Enabled = true;
            buttonpause.Enabled = false;
            buttonStop.Enabled = false;
            buttonpause.Text = "暂停";
            labelColon1.Visible = true;
            labelColon2.Visible = true;
        }

        private void Form1_Move(object sender, EventArgs e)
        {
            int screenRight = Screen.PrimaryScreen.Bounds.Right;
            int formRight = this.Left + this.Size.Width;
            if (Math.Abs(screenRight - formRight) <= 100)
                this.Left = screenRight - this.Size.Width;
            if(Math.Abs(this.Left)<=100)
                this.Left = 0;
            int screenBottom = Screen.PrimaryScreen.Bounds.Bottom;
            int formBottom = this.Top + this.Size.Height;
            if (Math.Abs(screenBottom - formBottom) <= 60)
            {
                this.Top = screenBottom - this.Height;
            }
            if (Math.Abs(this.Top) <= 100)
                this.Top = 0;

        }

        private void textBoxsecondcount_TextChanged(object sender, EventArgs e)
        {
            if (textBoxsecondcount.Text != "")
            {

                _jage = 0;
            }
            else {
                _jage = 1;
            }
            
        }
    }
}
