﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Pencial
{

    public partial class DlgPenWidth : Form
    {
        public int _PenWidth
        {
            get{return (int) numericUpDownWidth.Value;}
            set { numericUpDownWidth.Value = value; }
        }
        public DlgPenWidth()
        {
            InitializeComponent();
        }

        private void DlgPenWidth_Load(object sender, EventArgs e)
        {

        }
    }
}
