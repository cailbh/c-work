﻿namespace Pencial
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuItemFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemSaveAsPic = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItemClose = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemLine = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemRectangle = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemCircle = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItemStop = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemUndo = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemRedo = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemHand = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemWidth = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemColor = new System.Windows.Forms.ToolStripMenuItem();
            this.hcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemZoomOut = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemZoomIn = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonline = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonrectangle = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSketch = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtoneraser = new System.Windows.Forms.ToolStripSplitButton();
            this.smallToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.midToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hugeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonStop = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonUndo = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonRedo = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonWidth = new System.Windows.Forms.ToolStripDropDownButton();
            this.ToolStripMenuItem1px = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem2px = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem4px = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem8px = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButtonColor = new System.Windows.Forms.ToolStripSplitButton();
            this.RedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BlackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BlueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.YellowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtondelete = new System.Windows.Forms.ToolStripButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.panelContian = new System.Windows.Forms.Panel();
            this.panelDraw = new System.Windows.Forms.Panel();
            this.toolStripButtonzoomOut = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonzoomIn = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panelContian.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemFile,
            this.ToolStripMenuItem,
            this.ToolStripMenuItemSetting,
            this.hcToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1304, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuItemFile
            // 
            this.MenuItemFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemNew,
            this.MenuItemOpen,
            this.MenuItemSave,
            this.MenuItemSaveAs,
            this.MenuItemSaveAsPic,
            this.toolStripMenuItem2,
            this.MenuItemClose});
            this.MenuItemFile.Name = "MenuItemFile";
            this.MenuItemFile.Size = new System.Drawing.Size(44, 21);
            this.MenuItemFile.Text = "文件";
            // 
            // MenuItemNew
            // 
            this.MenuItemNew.Image = global::Pencial.Properties.Resources.file_new;
            this.MenuItemNew.Name = "MenuItemNew";
            this.MenuItemNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.MenuItemNew.Size = new System.Drawing.Size(149, 22);
            this.MenuItemNew.Text = "新建";
            this.MenuItemNew.ToolTipText = "新建文件";
            this.MenuItemNew.Click += new System.EventHandler(this.MenuItemNew_Click);
            // 
            // MenuItemOpen
            // 
            this.MenuItemOpen.Image = global::Pencial.Properties.Resources.file_open;
            this.MenuItemOpen.Name = "MenuItemOpen";
            this.MenuItemOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.MenuItemOpen.Size = new System.Drawing.Size(149, 22);
            this.MenuItemOpen.Text = "打开";
            this.MenuItemOpen.ToolTipText = "打开一个文件";
            this.MenuItemOpen.Click += new System.EventHandler(this.MenuItemOpen_Click);
            // 
            // MenuItemSave
            // 
            this.MenuItemSave.Image = global::Pencial.Properties.Resources.file_save;
            this.MenuItemSave.Name = "MenuItemSave";
            this.MenuItemSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W)));
            this.MenuItemSave.Size = new System.Drawing.Size(149, 22);
            this.MenuItemSave.Text = "保存";
            this.MenuItemSave.ToolTipText = "保存一个文件";
            this.MenuItemSave.Click += new System.EventHandler(this.MenuItemSave_Click);
            // 
            // MenuItemSaveAs
            // 
            this.MenuItemSaveAs.Name = "MenuItemSaveAs";
            this.MenuItemSaveAs.Size = new System.Drawing.Size(149, 22);
            this.MenuItemSaveAs.Text = "另存为";
            this.MenuItemSaveAs.Click += new System.EventHandler(this.MenuItemSaveAs_Click);
            // 
            // MenuItemSaveAsPic
            // 
            this.MenuItemSaveAsPic.Name = "MenuItemSaveAsPic";
            this.MenuItemSaveAsPic.Size = new System.Drawing.Size(149, 22);
            this.MenuItemSaveAsPic.Text = "另存为图片";
            this.MenuItemSaveAsPic.Click += new System.EventHandler(this.MenuItemSaveAsPic_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(146, 6);
            // 
            // MenuItemClose
            // 
            this.MenuItemClose.Name = "MenuItemClose";
            this.MenuItemClose.Size = new System.Drawing.Size(149, 22);
            this.MenuItemClose.Text = "关闭";
            this.MenuItemClose.Click += new System.EventHandler(this.MenuItemClose_Click);
            // 
            // ToolStripMenuItem
            // 
            this.ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemLine,
            this.MenuItemRectangle,
            this.MenuItemCircle,
            this.toolStripMenuItem1,
            this.MenuItemStop,
            this.ToolStripMenuItemUndo,
            this.ToolStripMenuItemRedo,
            this.ToolStripMenuItemHand});
            this.ToolStripMenuItem.Name = "ToolStripMenuItem";
            this.ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.ToolStripMenuItem.Text = "绘图";
            // 
            // MenuItemLine
            // 
            this.MenuItemLine.Image = global::Pencial.Properties.Resources.line;
            this.MenuItemLine.Name = "MenuItemLine";
            this.MenuItemLine.ShortcutKeyDisplayString = "";
            this.MenuItemLine.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.MenuItemLine.Size = new System.Drawing.Size(157, 22);
            this.MenuItemLine.Text = "直线 ";
            this.MenuItemLine.ToolTipText = "绘制直线";
            this.MenuItemLine.Click += new System.EventHandler(this.MenuItemLine_Click);
            // 
            // MenuItemRectangle
            // 
            this.MenuItemRectangle.Image = global::Pencial.Properties.Resources.rectangle;
            this.MenuItemRectangle.Name = "MenuItemRectangle";
            this.MenuItemRectangle.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.MenuItemRectangle.Size = new System.Drawing.Size(157, 22);
            this.MenuItemRectangle.Text = "矩形";
            this.MenuItemRectangle.ToolTipText = "绘制矩形";
            this.MenuItemRectangle.Click += new System.EventHandler(this.MenuItemRectangle_Click);
            // 
            // MenuItemCircle
            // 
            this.MenuItemCircle.Image = global::Pencial.Properties.Resources.circle;
            this.MenuItemCircle.Name = "MenuItemCircle";
            this.MenuItemCircle.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.MenuItemCircle.Size = new System.Drawing.Size(157, 22);
            this.MenuItemCircle.Text = "圆形";
            this.MenuItemCircle.ToolTipText = "绘制圆形";
            this.MenuItemCircle.Click += new System.EventHandler(this.MenuItemCircle_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(154, 6);
            // 
            // MenuItemStop
            // 
            this.MenuItemStop.Image = global::Pencial.Properties.Resources.stop;
            this.MenuItemStop.Name = "MenuItemStop";
            this.MenuItemStop.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.MenuItemStop.Size = new System.Drawing.Size(157, 22);
            this.MenuItemStop.Text = "停止";
            this.MenuItemStop.ToolTipText = "停止";
            this.MenuItemStop.Click += new System.EventHandler(this.MenuItemStop_Click);
            // 
            // ToolStripMenuItemUndo
            // 
            this.ToolStripMenuItemUndo.Image = global::Pencial.Properties.Resources.undo;
            this.ToolStripMenuItemUndo.Name = "ToolStripMenuItemUndo";
            this.ToolStripMenuItemUndo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.ToolStripMenuItemUndo.Size = new System.Drawing.Size(157, 22);
            this.ToolStripMenuItemUndo.Text = "撤销";
            this.ToolStripMenuItemUndo.ToolTipText = "撤销图元";
            this.ToolStripMenuItemUndo.Click += new System.EventHandler(this.ToolStripMenuItemUndo_Click);
            // 
            // ToolStripMenuItemRedo
            // 
            this.ToolStripMenuItemRedo.Image = global::Pencial.Properties.Resources.redo;
            this.ToolStripMenuItemRedo.Name = "ToolStripMenuItemRedo";
            this.ToolStripMenuItemRedo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.ToolStripMenuItemRedo.Size = new System.Drawing.Size(157, 22);
            this.ToolStripMenuItemRedo.Text = "重做";
            this.ToolStripMenuItemRedo.ToolTipText = "重做图元";
            this.ToolStripMenuItemRedo.Click += new System.EventHandler(this.ToolStripMenuItemRedo_Click);
            // 
            // ToolStripMenuItemHand
            // 
            this.ToolStripMenuItemHand.Image = global::Pencial.Properties.Resources.sketch;
            this.ToolStripMenuItemHand.Name = "ToolStripMenuItemHand";
            this.ToolStripMenuItemHand.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.K)));
            this.ToolStripMenuItemHand.Size = new System.Drawing.Size(157, 22);
            this.ToolStripMenuItemHand.Text = "徒手画";
            this.ToolStripMenuItemHand.ToolTipText = "徒手画";
            this.ToolStripMenuItemHand.Click += new System.EventHandler(this.ToolStripMenuItemHand_Click);
            // 
            // ToolStripMenuItemSetting
            // 
            this.ToolStripMenuItemSetting.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemWidth,
            this.ToolStripMenuItemColor});
            this.ToolStripMenuItemSetting.Name = "ToolStripMenuItemSetting";
            this.ToolStripMenuItemSetting.Size = new System.Drawing.Size(44, 21);
            this.ToolStripMenuItemSetting.Text = "设置";
            this.ToolStripMenuItemSetting.ToolTipText = "设置";
            // 
            // ToolStripMenuItemWidth
            // 
            this.ToolStripMenuItemWidth.Image = global::Pencial.Properties.Resources.width;
            this.ToolStripMenuItemWidth.Name = "ToolStripMenuItemWidth";
            this.ToolStripMenuItemWidth.Size = new System.Drawing.Size(100, 22);
            this.ToolStripMenuItemWidth.Text = "线宽";
            this.ToolStripMenuItemWidth.ToolTipText = "线宽";
            this.ToolStripMenuItemWidth.Click += new System.EventHandler(this.ToolStripMenuItemWidth_Click);
            // 
            // ToolStripMenuItemColor
            // 
            this.ToolStripMenuItemColor.Image = global::Pencial.Properties.Resources.color;
            this.ToolStripMenuItemColor.Name = "ToolStripMenuItemColor";
            this.ToolStripMenuItemColor.Size = new System.Drawing.Size(100, 22);
            this.ToolStripMenuItemColor.Text = "颜色";
            this.ToolStripMenuItemColor.ToolTipText = "颜色";
            this.ToolStripMenuItemColor.Click += new System.EventHandler(this.ToolStripMenuItemColor_Click);
            // 
            // hcToolStripMenuItem
            // 
            this.hcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItemZoomOut,
            this.MenuItemZoomIn});
            this.hcToolStripMenuItem.Name = "hcToolStripMenuItem";
            this.hcToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.hcToolStripMenuItem.Text = "查看";
            // 
            // MenuItemZoomOut
            // 
            this.MenuItemZoomOut.Image = global::Pencial.Properties.Resources.ZoomIn;
            this.MenuItemZoomOut.Name = "MenuItemZoomOut";
            this.MenuItemZoomOut.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.O)));
            this.MenuItemZoomOut.Size = new System.Drawing.Size(181, 22);
            this.MenuItemZoomOut.Text = "放大";
            this.MenuItemZoomOut.Click += new System.EventHandler(this.MenuItemZoomOut_Click);
            // 
            // MenuItemZoomIn
            // 
            this.MenuItemZoomIn.Image = global::Pencial.Properties.Resources.ZoomOut;
            this.MenuItemZoomIn.Name = "MenuItemZoomIn";
            this.MenuItemZoomIn.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.MenuItemZoomIn.Size = new System.Drawing.Size(181, 22);
            this.MenuItemZoomIn.Text = "缩小";
            this.MenuItemZoomIn.Click += new System.EventHandler(this.MenuItemZoomIn_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 678);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1304, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StripStatusLabel1
            // 
            this.StripStatusLabel1.Name = "StripStatusLabel1";
            this.StripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.StripStatusLabel1.Text = "鼠标位置： x= ，y=";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonline,
            this.toolStripButtonrectangle,
            this.toolStripButton1,
            this.toolStripButtonSketch,
            this.toolStripButtoneraser,
            this.toolStripSeparator1,
            this.toolStripButtonStop,
            this.toolStripSeparator2,
            this.toolStripButtonUndo,
            this.toolStripButtonRedo,
            this.toolStripButtonWidth,
            this.toolStripButtonColor,
            this.toolStripSeparator3,
            this.toolStripButtondelete,
            this.toolStripButtonzoomOut,
            this.toolStripButtonzoomIn});
            this.toolStrip1.Location = new System.Drawing.Point(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1304, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonline
            // 
            this.toolStripButtonline.Image = global::Pencial.Properties.Resources.line;
            this.toolStripButtonline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonline.Name = "toolStripButtonline";
            this.toolStripButtonline.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonline.Text = "直线";
            this.toolStripButtonline.Click += new System.EventHandler(this.MenuItemLine_Click);
            // 
            // toolStripButtonrectangle
            // 
            this.toolStripButtonrectangle.Image = global::Pencial.Properties.Resources.rectangle;
            this.toolStripButtonrectangle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonrectangle.Name = "toolStripButtonrectangle";
            this.toolStripButtonrectangle.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonrectangle.Text = "矩形";
            this.toolStripButtonrectangle.Click += new System.EventHandler(this.MenuItemRectangle_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::Pencial.Properties.Resources.circle;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(40, 22);
            this.toolStripButton1.Text = "圆";
            this.toolStripButton1.Click += new System.EventHandler(this.MenuItemCircle_Click);
            // 
            // toolStripButtonSketch
            // 
            this.toolStripButtonSketch.Image = global::Pencial.Properties.Resources.sketch;
            this.toolStripButtonSketch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSketch.Name = "toolStripButtonSketch";
            this.toolStripButtonSketch.Size = new System.Drawing.Size(64, 22);
            this.toolStripButtonSketch.Text = "徒手画";
            this.toolStripButtonSketch.Click += new System.EventHandler(this.ToolStripMenuItemHand_Click);
            // 
            // toolStripButtoneraser
            // 
            this.toolStripButtoneraser.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smallToolStripMenuItem,
            this.midToolStripMenuItem,
            this.bigToolStripMenuItem,
            this.hugeToolStripMenuItem});
            this.toolStripButtoneraser.Image = global::Pencial.Properties.Resources.era;
            this.toolStripButtoneraser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtoneraser.Name = "toolStripButtoneraser";
            this.toolStripButtoneraser.Size = new System.Drawing.Size(76, 22);
            this.toolStripButtoneraser.Text = "橡皮擦";
            this.toolStripButtoneraser.Click += new System.EventHandler(this.toolStripButtoneraser_Click);
            // 
            // smallToolStripMenuItem
            // 
            this.smallToolStripMenuItem.Image = global::Pencial.Properties.Resources.small;
            this.smallToolStripMenuItem.Name = "smallToolStripMenuItem";
            this.smallToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.smallToolStripMenuItem.Text = "小";
            this.smallToolStripMenuItem.Click += new System.EventHandler(this.smallToolStripMenuItem_Click);
            // 
            // midToolStripMenuItem
            // 
            this.midToolStripMenuItem.Image = global::Pencial.Properties.Resources.mid;
            this.midToolStripMenuItem.Name = "midToolStripMenuItem";
            this.midToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.midToolStripMenuItem.Text = "中";
            this.midToolStripMenuItem.Click += new System.EventHandler(this.midToolStripMenuItem_Click);
            // 
            // bigToolStripMenuItem
            // 
            this.bigToolStripMenuItem.Image = global::Pencial.Properties.Resources.big;
            this.bigToolStripMenuItem.Name = "bigToolStripMenuItem";
            this.bigToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.bigToolStripMenuItem.Text = "大";
            this.bigToolStripMenuItem.Click += new System.EventHandler(this.bigToolStripMenuItem_Click);
            // 
            // hugeToolStripMenuItem
            // 
            this.hugeToolStripMenuItem.Image = global::Pencial.Properties.Resources.huge;
            this.hugeToolStripMenuItem.Name = "hugeToolStripMenuItem";
            this.hugeToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.hugeToolStripMenuItem.Text = "超大";
            this.hugeToolStripMenuItem.Click += new System.EventHandler(this.hugeToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonStop
            // 
            this.toolStripButtonStop.Image = global::Pencial.Properties.Resources.stop;
            this.toolStripButtonStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonStop.Name = "toolStripButtonStop";
            this.toolStripButtonStop.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonStop.Text = "停止";
            this.toolStripButtonStop.Click += new System.EventHandler(this.MenuItemStop_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonUndo
            // 
            this.toolStripButtonUndo.Image = global::Pencial.Properties.Resources.undo;
            this.toolStripButtonUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonUndo.Name = "toolStripButtonUndo";
            this.toolStripButtonUndo.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonUndo.Text = "撤销";
            this.toolStripButtonUndo.Click += new System.EventHandler(this.ToolStripMenuItemUndo_Click);
            // 
            // toolStripButtonRedo
            // 
            this.toolStripButtonRedo.Image = global::Pencial.Properties.Resources.redo;
            this.toolStripButtonRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRedo.Name = "toolStripButtonRedo";
            this.toolStripButtonRedo.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonRedo.Text = "重做";
            this.toolStripButtonRedo.Click += new System.EventHandler(this.ToolStripMenuItemRedo_Click);
            // 
            // toolStripButtonWidth
            // 
            this.toolStripButtonWidth.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem1px,
            this.ToolStripMenuItem2px,
            this.ToolStripMenuItem4px,
            this.ToolStripMenuItem8px});
            this.toolStripButtonWidth.Image = global::Pencial.Properties.Resources.width;
            this.toolStripButtonWidth.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonWidth.Name = "toolStripButtonWidth";
            this.toolStripButtonWidth.Size = new System.Drawing.Size(61, 22);
            this.toolStripButtonWidth.Text = "线宽";
            // 
            // ToolStripMenuItem1px
            // 
            this.ToolStripMenuItem1px.Image = global::Pencial.Properties.Resources.width1;
            this.ToolStripMenuItem1px.Name = "ToolStripMenuItem1px";
            this.ToolStripMenuItem1px.Size = new System.Drawing.Size(97, 22);
            this.ToolStripMenuItem1px.Text = "1px";
            this.ToolStripMenuItem1px.ToolTipText = "线宽设置为1px";
            this.ToolStripMenuItem1px.Click += new System.EventHandler(this.ToolStripMenuItem1px_Click);
            // 
            // ToolStripMenuItem2px
            // 
            this.ToolStripMenuItem2px.Image = global::Pencial.Properties.Resources.width2;
            this.ToolStripMenuItem2px.Name = "ToolStripMenuItem2px";
            this.ToolStripMenuItem2px.Size = new System.Drawing.Size(97, 22);
            this.ToolStripMenuItem2px.Text = "2px";
            this.ToolStripMenuItem2px.ToolTipText = "线宽设置为2px";
            this.ToolStripMenuItem2px.Click += new System.EventHandler(this.ToolStripMenuItem2px_Click);
            // 
            // ToolStripMenuItem4px
            // 
            this.ToolStripMenuItem4px.Image = global::Pencial.Properties.Resources.width4;
            this.ToolStripMenuItem4px.Name = "ToolStripMenuItem4px";
            this.ToolStripMenuItem4px.Size = new System.Drawing.Size(97, 22);
            this.ToolStripMenuItem4px.Text = "4px";
            this.ToolStripMenuItem4px.ToolTipText = "线宽设置为4px";
            this.ToolStripMenuItem4px.Click += new System.EventHandler(this.ToolStripMenuItem4px_Click);
            // 
            // ToolStripMenuItem8px
            // 
            this.ToolStripMenuItem8px.Image = global::Pencial.Properties.Resources.width8;
            this.ToolStripMenuItem8px.Name = "ToolStripMenuItem8px";
            this.ToolStripMenuItem8px.Size = new System.Drawing.Size(97, 22);
            this.ToolStripMenuItem8px.Text = "8px";
            this.ToolStripMenuItem8px.ToolTipText = "线宽设置为8px";
            this.ToolStripMenuItem8px.Click += new System.EventHandler(this.ToolStripMenuItem8px_Click);
            // 
            // toolStripButtonColor
            // 
            this.toolStripButtonColor.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RedToolStripMenuItem,
            this.BlackToolStripMenuItem,
            this.BlueToolStripMenuItem,
            this.GreenToolStripMenuItem,
            this.YellowToolStripMenuItem});
            this.toolStripButtonColor.Image = global::Pencial.Properties.Resources.color;
            this.toolStripButtonColor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonColor.Name = "toolStripButtonColor";
            this.toolStripButtonColor.Size = new System.Drawing.Size(64, 22);
            this.toolStripButtonColor.Text = "颜色";
            this.toolStripButtonColor.ToolTipText = "颜色";
            // 
            // RedToolStripMenuItem
            // 
            this.RedToolStripMenuItem.Image = global::Pencial.Properties.Resources.color_red;
            this.RedToolStripMenuItem.Name = "RedToolStripMenuItem";
            this.RedToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.RedToolStripMenuItem.Text = "红色";
            this.RedToolStripMenuItem.ToolTipText = "设置颜色";
            this.RedToolStripMenuItem.Click += new System.EventHandler(this.RedToolStripMenuItem_Click);
            // 
            // BlackToolStripMenuItem
            // 
            this.BlackToolStripMenuItem.Image = global::Pencial.Properties.Resources.color_black;
            this.BlackToolStripMenuItem.Name = "BlackToolStripMenuItem";
            this.BlackToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.BlackToolStripMenuItem.Text = "黑色";
            this.BlackToolStripMenuItem.ToolTipText = "设置颜色";
            this.BlackToolStripMenuItem.Click += new System.EventHandler(this.BlackToolStripMenuItem_Click);
            // 
            // BlueToolStripMenuItem
            // 
            this.BlueToolStripMenuItem.Image = global::Pencial.Properties.Resources.color_blue;
            this.BlueToolStripMenuItem.Name = "BlueToolStripMenuItem";
            this.BlueToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.BlueToolStripMenuItem.Text = "蓝色";
            this.BlueToolStripMenuItem.ToolTipText = "设置颜色";
            this.BlueToolStripMenuItem.Click += new System.EventHandler(this.BlueToolStripMenuItem_Click);
            // 
            // GreenToolStripMenuItem
            // 
            this.GreenToolStripMenuItem.Image = global::Pencial.Properties.Resources.color_green;
            this.GreenToolStripMenuItem.Name = "GreenToolStripMenuItem";
            this.GreenToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.GreenToolStripMenuItem.Text = "绿色";
            this.GreenToolStripMenuItem.ToolTipText = "设置颜色";
            this.GreenToolStripMenuItem.Click += new System.EventHandler(this.GreenToolStripMenuItem_Click);
            // 
            // YellowToolStripMenuItem
            // 
            this.YellowToolStripMenuItem.Image = global::Pencial.Properties.Resources.color_yellow;
            this.YellowToolStripMenuItem.Name = "YellowToolStripMenuItem";
            this.YellowToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.YellowToolStripMenuItem.Text = "黄色";
            this.YellowToolStripMenuItem.ToolTipText = "设置颜色";
            this.YellowToolStripMenuItem.Click += new System.EventHandler(this.YellowToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtondelete
            // 
            this.toolStripButtondelete.Image = global::Pencial.Properties.Resources.del;
            this.toolStripButtondelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtondelete.Name = "toolStripButtondelete";
            this.toolStripButtondelete.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtondelete.Text = "删除";
            this.toolStripButtondelete.Click += new System.EventHandler(this.toolStripButtondelete_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "*.dwg";
            this.openFileDialog1.Filter = "所有文件|*.*|图形文件(*.dwg)|*.dwg";
            this.openFileDialog1.FilterIndex = 2;
            this.openFileDialog1.InitialDirectory = "c:\\";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileName = "*.dwg";
            this.saveFileDialog1.Filter = "所有文件|*.*|图形文件(*.dwg)|*.dwg";
            this.saveFileDialog1.FilterIndex = 2;
            this.saveFileDialog1.InitialDirectory = "c:\\";
            // 
            // saveFileDialog2
            // 
            this.saveFileDialog2.FileName = "*.gif";
            this.saveFileDialog2.Filter = "所有文件|*.*|GIF文件|*.gif|JPG文件|*.jpg";
            this.saveFileDialog2.FilterIndex = 2;
            this.saveFileDialog2.Title = "保存为图片";
            // 
            // panelContian
            // 
            this.panelContian.AutoScroll = true;
            this.panelContian.Controls.Add(this.panelDraw);
            this.panelContian.Location = new System.Drawing.Point(0, 53);
            this.panelContian.Name = "panelContian";
            this.panelContian.Size = new System.Drawing.Size(1304, 622);
            this.panelContian.TabIndex = 3;
            // 
            // panelDraw
            // 
            this.panelDraw.BackColor = System.Drawing.Color.White;
            this.panelDraw.Location = new System.Drawing.Point(8, 10);
            this.panelDraw.Name = "panelDraw";
            this.panelDraw.Size = new System.Drawing.Size(582, 361);
            this.panelDraw.TabIndex = 0;
            this.panelDraw.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseMove);
            this.panelDraw.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseDown);
            this.panelDraw.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseUp);
            // 
            // toolStripButtonzoomOut
            // 
            this.toolStripButtonzoomOut.Image = global::Pencial.Properties.Resources.ZoomIn;
            this.toolStripButtonzoomOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonzoomOut.Name = "toolStripButtonzoomOut";
            this.toolStripButtonzoomOut.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonzoomOut.Text = "放大";
            this.toolStripButtonzoomOut.Click += new System.EventHandler(this.MenuItemZoomOut_Click);
            // 
            // toolStripButtonzoomIn
            // 
            this.toolStripButtonzoomIn.Image = global::Pencial.Properties.Resources.ZoomOut;
            this.toolStripButtonzoomIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonzoomIn.Name = "toolStripButtonzoomIn";
            this.toolStripButtonzoomIn.Size = new System.Drawing.Size(52, 22);
            this.toolStripButtonzoomIn.Text = "缩小";
            this.toolStripButtonzoomIn.Click += new System.EventHandler(this.MenuItemZoomIn_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1304, 700);
            this.Controls.Add(this.panelContian);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.Text = "我的画笔";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseUp);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FormMain_Paint);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FormMain_MouseMove);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panelContian.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItemLine;
        private System.Windows.Forms.ToolStripMenuItem MenuItemRectangle;
        private System.Windows.Forms.ToolStripMenuItem MenuItemCircle;
        private System.Windows.Forms.ToolStripMenuItem MenuItemStop;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemSetting;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemWidth;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemColor;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemUndo;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemRedo;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StripStatusLabel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonline;
        private System.Windows.Forms.ToolStripButton toolStripButtonrectangle;
        private System.Windows.Forms.ToolStripButton toolStripButtonSketch;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButtonStop;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButtonUndo;
        private System.Windows.Forms.ToolStripButton toolStripButtonRedo;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButtonWidth;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem1px;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem2px;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem4px;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem8px;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButtondelete;
        private System.Windows.Forms.ToolStripMenuItem MenuItemFile;
        private System.Windows.Forms.ToolStripMenuItem MenuItemNew;
        private System.Windows.Forms.ToolStripSplitButton toolStripButtonColor;
        private System.Windows.Forms.ToolStripMenuItem RedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BlackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BlueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem GreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem YellowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItemOpen;
        private System.Windows.Forms.ToolStripMenuItem MenuItemSave;
        private System.Windows.Forms.ToolStripMenuItem MenuItemSaveAs;
        private System.Windows.Forms.ToolStripMenuItem MenuItemSaveAsPic;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem MenuItemClose;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemHand;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSplitButton toolStripButtoneraser;
        private System.Windows.Forms.ToolStripMenuItem smallToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem midToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bigToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hugeToolStripMenuItem;
        private System.Windows.Forms.Panel panelContian;
        private System.Windows.Forms.Panel panelDraw;
        private System.Windows.Forms.ToolStripMenuItem hcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItemZoomOut;
        private System.Windows.Forms.ToolStripMenuItem MenuItemZoomIn;
        private System.Windows.Forms.ToolStripButton toolStripButtonzoomOut;
        private System.Windows.Forms.ToolStripButton toolStripButtonzoomIn;
    }
}

