﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.IO;
using System.Drawing.Imaging;
namespace Pencial
{
    public partial class FormMain : Form
    {
        private Color _tempColor;
        private int _tempWidth;
        private List<shape> _listShape = new List<shape>();
        private List<shape> _listTempShape = new List<shape>();
        private shape _tempShape = null;
        private DrawType _drawType = DrawType.Stop;
        private int _drawWidth = 10;
        private Color _drawColor = Color.Red;
        private int _deleteJudge = 0;
        BufferedGraphicsContext _bufGrahCont = null;
        BufferedGraphics _bufGraph = null;
        private string _fileName = "";
        private double _zoomRatio = 1;
        private Size _panelDrawInitSize = new Size(0, 0);
        private Boolean _saveFlag = false;
        public FormMain()
        {
            InitializeComponent();
        }

      



        private void FormMain_MouseDown(object sender, MouseEventArgs e)
        {
            if (_deleteJudge == 1)
            {
                shape _tempSh = null;
                int x = (int)(e.X/_zoomRatio), y = (int)(e.Y/_zoomRatio);
                double d=100000;
                for (int i =  _listShape.Count-1; i > -1; i--)
                {
                    _tempSh=_listShape[i];
                    if (_tempSh._shapeType == 1)
                    {
                        //线
                        //d=abs((x1-x0)(y2-y0)-(x2-x0)(y1-y0))/sqrt((x1-x2)^2+(y1-y2)^2);
                        d =(double) Math.Abs((_tempSh._po1.X - x) * (_tempSh._po2.Y - y) - (_tempSh._po2.X - x) * (_tempSh._po1.Y - y)) / Math.Sqrt((_tempSh._po1.X - _tempSh._po2.X) * (_tempSh._po1.X - _tempSh._po2.X) + (_tempSh._po1.Y - _tempSh._po2.Y) * (_tempSh._po1.Y - _tempSh._po2.Y));                
                        
                    }
                    else if (_tempSh._shapeType == 2)
                    {
                        //矩形
                        if ((x < Math.Max(_tempSh._po1.X, _tempSh._po2.X) + _tempSh._PenWidth / 2) && (x > Math.Min(_tempSh._po1.X, _tempSh._po2.X) - _tempSh._PenWidth / 2) && (y < Math.Max(_tempSh._po1.Y, _tempSh._po2.Y) + _tempSh._PenWidth / 2) && (y > Math.Min(_tempSh._po1.Y, _tempSh._po2.Y) - _tempSh._PenWidth / 2))
                        {
                        d = Math.Min(Math.Abs(_tempSh._po1.X - x), Math.Abs(_tempSh._po1.Y - y));
                        d = Math.Min(Math.Abs(_tempSh._po2.X - x), d);
                        d = Math.Min(Math.Abs(_tempSh._po2.Y - y), d);
                        }
                        else
                        d = 20000;
                    }
                    else if (_tempSh._shapeType == 3)
                    {
                        //圆
                        d = Math.Abs(Math.Sqrt((_tempSh._po1.X - x) * (_tempSh._po1.X - x) + (_tempSh._po1.Y - y) * (_tempSh._po1.Y - y)) - _tempSh._circleR);

                    }
                    else if (_tempSh._shapeType == 4)
                    {
                        d = 20000;
                        for (int q = 0; q < _tempSh._ptList.Count; q++)
                        {
                            d = Math.Min(d, (Math.Sqrt((_tempSh._ptList[q].X - x) * (_tempSh._ptList[q].X - x) + (_tempSh._ptList[q].Y - y) * (_tempSh._ptList[q].Y - y))));
                        }
                    }
                    if ((d) < _tempSh._PenWidth / 2)
                    {
                        _listTempShape.Add(_listShape[i]);
                        _listShape.Remove(_listShape[i]);
                        _bufGraph.Graphics.Clear(Color.White);
                        foreach (shape shape in _listShape)
                         shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                        _bufGraph.Render();
                        ToolStripMenuItemRedo.Enabled = true;
                        toolStripButtonRedo.Enabled = true;
                        _saveFlag = true;
                    }
                }
            }
            else if (_drawType != DrawType.Stop)
            {
                if (_drawType == DrawType.Line)
                {
                    _tempShape = new Line();
                    ((Line)_tempShape).P1 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                }
                else if (_drawType == DrawType.Rectangle)
                {
                    _tempShape = new Rectangle();
                    ((Rectangle)_tempShape).P1 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));

                }
                else if (_drawType == DrawType.Circle)
                {
                    _tempShape = new Circle();
                    ((Circle)_tempShape).PCenter = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));

                }
                else if (_drawType == DrawType.Sketch)
                {
                    _tempShape = new Sketch();
                    ((Sketch)_tempShape).PointList.Add(new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio)));
                }
                _tempShape._PenColor = _drawColor;
                _tempShape._PenWidth = _drawWidth;
            }
        }

        private void FormMain_MouseUp(object sender, MouseEventArgs e)
        {
            if (_deleteJudge != 1)
            {
                if (_drawType != DrawType.Stop)
            {
                if (_drawType == DrawType.Line)
                {
                    ((Line)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                }
                else if (_drawType == DrawType.Rectangle)
                {
                    ((Rectangle)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));

                }
                else if (_drawType == DrawType.Circle)
                {
                    ((Circle)_tempShape).PCenter2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                    ((Circle)_tempShape).R = (float)(Math.Sqrt(Math.Pow(((int)(e.X / _zoomRatio) - ((Circle)_tempShape).PCenter.X), 2) + Math.Pow(((int)(e.Y / _zoomRatio) - ((Circle)_tempShape).PCenter.Y), 2)) / 2);
                }
                else if(_drawType==DrawType.Sketch)
                    ((Sketch)_tempShape).PointList.Add(new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio)));
                _listShape.Add(_tempShape);
                _saveFlag = true;
                _listTempShape.Clear();
                ToolStripMenuItemRedo.Enabled = false;
                toolStripButtonRedo.Enabled = false;
                toolStripButtonUndo.Enabled = true;
                ToolStripMenuItemUndo.Enabled = true;
                _bufGraph.Graphics.Clear(Color.White);
                foreach (shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());

            }
            }
            
        }

        private void FormMain_MouseMove(object sender, MouseEventArgs e)
        {
            StripStatusLabel1.Text = "当前坐标为:   x=" + e.X.ToString() + "  y=" + e.Y.ToString();
            if (_deleteJudge != 1) 
            { 
            if (e.Button == MouseButtons.Left)
            {
                if (_drawType != DrawType.Stop)
                {
                    _bufGraph.Graphics.Clear(Color.White);
                    foreach (shape shape in _listShape)
                        shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                    if (_drawType == DrawType.Line)
                    {
                        ((Line)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                    }
                    else if (_drawType == DrawType.Rectangle)
                    {
                        ((Rectangle)_tempShape).P2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));

                    }
                    else if (_drawType == DrawType.Circle)
                    {
                        ((Circle)_tempShape).PCenter2 = new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio));
                        ((Circle)_tempShape).R = (float)(Math.Sqrt(Math.Pow(((int)(e.X / _zoomRatio) - ((Circle)_tempShape).PCenter.X), 2) + Math.Pow(((int)(e.Y / _zoomRatio) - ((Circle)_tempShape).PCenter.Y), 2)) / 2);

                    }
                    else if (_drawType == DrawType.Sketch)
                        ((Sketch)_tempShape).PointList.Add(new Point((int)(e.X / _zoomRatio), (int)(e.Y / _zoomRatio)));
                    _tempShape.Draw(_bufGraph.Graphics, DashStyle.DashDot,_zoomRatio);
                    _bufGraph.Render(panelDraw.CreateGraphics());

                }
            }
            }
            
        }

        private void FormMain_Paint(object sender, PaintEventArgs e)
        {
            _bufGraph.Graphics.Clear(Color.White);
            foreach (shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
            _bufGraph.Render(panelDraw.CreateGraphics());
        }

        private void MenuItemRectangle_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Rectangle;
        }

        private void MenuItemCircle_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Circle;
        }

        private void MenuItemStop_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Stop;
        }

        private void MenuItemLine_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Line;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            _panelDrawInitSize.Width = panelDraw.Width;
            _panelDrawInitSize.Height = panelDraw.Height;
            _bufGrahCont = BufferedGraphicsManager.Current;
            _bufGraph = _bufGrahCont.Allocate(panelDraw.CreateGraphics(), this.ClientRectangle);
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            ToolStripMenuItemUndo.Enabled = false;
            toolStripButtonUndo.Enabled = false;
            ToolStripMenuItemRedo.Enabled = false;
            toolStripButtonRedo.Enabled = false;
            menuStrip1.Cursor = Cursors.Hand;
            Cursor penCur = new Cursor("pen.cur");
            this.Cursor = penCur;
            toolStrip1.Cursor = Cursors.Hand;
            statusStrip1.Cursor = Cursors.Arrow;
        }

        private void ToolStripMenuItemWidth_Click(object sender, EventArgs e)
        {
            DlgPenWidth dlgPenWidth = new DlgPenWidth();
            dlgPenWidth._PenWidth = _drawWidth;
            if (dlgPenWidth.ShowDialog(this) == DialogResult.OK)
            {
                _drawWidth = (int)(dlgPenWidth._PenWidth);
            }
        }

        private void ToolStripMenuItemColor_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = _drawColor;
            if (colorDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _drawColor = colorDialog1.Color;
            }
        }

        private void ToolStripMenuItemUndo_Click(object sender, EventArgs e)
        {
            if (_listShape.Count != 0)
            {
                _listTempShape.Add(_listShape[_listShape.Count - 1]);
                _listShape.RemoveAt(_listShape.Count - 1);
                _bufGraph.Graphics.Clear(Color.White);
                foreach (shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                _bufGraph.Render();
                ToolStripMenuItemRedo.Enabled = true;
                toolStripButtonRedo.Enabled = true;
            }
            else
            {
                ToolStripMenuItemUndo.Enabled = false;
                toolStripButtonUndo.Enabled = false;
                ToolStripMenuItemRedo.Enabled = true;
                toolStripButtonRedo.Enabled = true;
                _saveFlag = true;
            }
        }

        private void ToolStripMenuItemRedo_Click(object sender, EventArgs e)
        {
            if (_listTempShape.Count != 0)
            {
                _listShape.Add(_listTempShape[_listTempShape.Count - 1]);
                _listTempShape.RemoveAt(_listTempShape.Count - 1);
              //  _bufGraph.Graphics.Clear(Color.White);
                foreach (shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());
                ToolStripMenuItemUndo.Enabled = true;
                toolStripButtonUndo.Enabled = true;
            }
            else
            {
                ToolStripMenuItemRedo.Enabled = false;
                toolStripButtonRedo.Enabled = false;
                _saveFlag = true;
            }
        }

        private void ToolStripMenuItem1px_Click(object sender, EventArgs e)
        {
            _drawWidth = 1;
        }

        private void ToolStripMenuItem2px_Click(object sender, EventArgs e)
        {
            _drawWidth = 2;
        }

        private void ToolStripMenuItem4px_Click(object sender, EventArgs e)
        {
            _drawWidth = 4;
        }

        private void ToolStripMenuItem8px_Click(object sender, EventArgs e)
        {
            _drawWidth = 8;
        }

        private void toolStripButtondelete_Click(object sender, EventArgs e)
        {
            if(toolStripButtondelete.Text=="删除"){
                toolStripButtondelete.Text="停止";
            _deleteJudge = 1;
            _drawType = DrawType.Stop;
            ToolStripMenuItemUndo.Enabled = false;
            toolStripButtonUndo.Enabled = false;
            ToolStripMenuItemRedo.Enabled = false;
            toolStripButtonRedo.Enabled = false;
            toolStripButtonrectangle.Enabled = false;
            toolStripButtonline.Enabled = false;
            toolStripButtonSketch.Enabled = false;
            MenuItemCircle.Enabled = false;
            MenuItemLine.Enabled = false;
            MenuItemRectangle.Enabled = false;
            menuStrip1.Cursor = Cursors.Hand;
            Cursor penCur = new Cursor("del.cur");
            this.Cursor = penCur;
            toolStrip1.Cursor = Cursors.Hand;
            statusStrip1.Cursor = Cursors.Arrow;
            }
            else if (toolStripButtondelete.Text == "停止")
            {
                toolStripButtondelete.Text = "删除";
                _deleteJudge = 0;
                _drawType = DrawType.Stop;
                ToolStripMenuItemUndo.Enabled = true;
                toolStripButtonUndo.Enabled = true;
                ToolStripMenuItemRedo.Enabled = true;
                toolStripButtonRedo.Enabled = true;
                toolStripButtonrectangle.Enabled = true;
                toolStripButtonline.Enabled = true;
                toolStripButtonSketch.Enabled = true;
                MenuItemCircle.Enabled = true;
                MenuItemLine.Enabled = true;
                MenuItemRectangle.Enabled = true;
                menuStrip1.Cursor = Cursors.Hand;
                Cursor penCur = new Cursor("pen.cur");
                this.Cursor = penCur;
                toolStrip1.Cursor = Cursors.Hand;
                statusStrip1.Cursor = Cursors.Arrow;
            }
        }

        private void RedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Red;
        }

        private void BlackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Black;
        }

        private void BlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Blue;
        }

        private void GreenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Green;
        }

        private void YellowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _drawColor = Color.Yellow;
        }

        private void MenuItemNew_Click(object sender, EventArgs e)
        {
            if (_saveFlag == true)
            {
                if (MessageBox.Show("图形已经改变，你是否需要保存？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    MenuItemSave_Click(null, null);
                }
            }
            _listShape.Clear();
            _listTempShape.Clear();
            _bufGraph.Graphics.Clear(Color.White);
            _bufGraph.Render(panelDraw.CreateGraphics());
            _fileName = "";
            this.Text = "画笔-无标题";
            ToolStripMenuItemUndo.Enabled = false;
            toolStripButtonUndo.Enabled = false;
            ToolStripMenuItemRedo.Enabled = false;
            toolStripButtonRedo.Enabled = false;
            _saveFlag = false;
        }

        private void MenuItemOpen_Click(object sender, EventArgs e)
        {
            
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK) 
            {
                MenuItemNew_Click(null, null);
                _fileName = openFileDialog1.FileName;
                this.Text = "画笔-" + _fileName;
                FileStream fs = new FileStream(_fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                int shapeCount = br.ReadInt32();
                for (int i = 0; i < shapeCount; i++)
                {
                    string ShapeType = br.ReadString();
                    if (ShapeType == "Pencial.Line")
                    {
                        Line shape = new Line();
                        shape.Read(br);
                        _listShape.Add(shape);                       
                    }
                    else if (ShapeType == "Pencial.Rectangle")
                    {
                        Rectangle shape = new Rectangle();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else if (ShapeType == "Pencial.Circle")
                    {
                        Circle shape = new Circle();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else if (ShapeType == "Pencial.Sketch")
                    {
                        Sketch shape = new  Sketch();
                        shape.Read(br);
                        _listShape.Add(shape);
                    }
                    else
                        MessageBox.Show("图元类型错误。","错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                br.Close();
                fs.Close();
                _saveFlag = false;
                _bufGraph.Graphics.Clear(Color.White);
                foreach (shape shape in _listShape)
                    shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
                _bufGraph.Render(panelDraw.CreateGraphics());
            }
        }

        private void MenuItemSave_Click(object sender, EventArgs e)
        {
            if (_fileName == "")
            {
                if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
                {
                    _fileName = saveFileDialog1.FileName;
                    this.Text = "画笔-" + _fileName;

                }
                else
                    return;
            }
            FileStream fs = new FileStream(_fileName, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(_listShape.Count);
            foreach (shape tempshape in _listShape)
            {
                bw.Write(tempshape.GetType().ToString());
                tempshape.Write(bw);
            }
            bw.Close();
            fs.Close();
            _saveFlag = false;

        }
        private void MenuItemSaveAs_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                _fileName = saveFileDialog1.FileName;
                this.Text = "画笔-" + _fileName;
                FileStream fs = new FileStream(_fileName, FileMode.Create);
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(_listShape.Count);
                foreach (shape tempshape in _listShape)
                {
                    bw.Write(tempshape.GetType().ToString());
                    tempshape.Write(bw);
                }
                bw.Close();
                fs.Close();
                _saveFlag = false;
            }
        }

        private void MenuItemSaveAsPic_Click(object sender, EventArgs e)
        {
            if (saveFileDialog2.ShowDialog(this) == DialogResult.OK)
            {
                Bitmap bitmap = new Bitmap(this.ClientRectangle.Width, this.ClientRectangle.Height);
                Graphics gBitmap = Graphics.FromImage(bitmap);
                _bufGraph.Render(gBitmap);
                string extension = System.IO.Path.GetExtension(saveFileDialog2.FileName);
                if (extension == ".jpg")
                    bitmap.Save(saveFileDialog2.FileName, ImageFormat.Jpeg);
                else if (extension == ".gif")
                    bitmap.Save(saveFileDialog2.FileName, ImageFormat.Gif);
                else if (extension == ".bmp")
                    bitmap.Save(saveFileDialog2.FileName, ImageFormat.Bmp);
                else
                    MessageBox.Show("对不起，暂不支持该图片格式。", extension, MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                _saveFlag = false;
            }
        }

        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_saveFlag == true)
            {
                if (MessageBox.Show("图形已经改变，你是否需要保存？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    MenuItemSave_Click(null, null);
                }
            }
        }

        private void MenuItemClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ToolStripMenuItemHand_Click(object sender, EventArgs e)
        {
            _drawType = DrawType.Sketch;
        }

        private void toolStripButtoneraser_Click(object sender, EventArgs e)
        {
            
            if(toolStripButtoneraser.Text=="橡皮擦"){
                _tempWidth = _drawWidth;
                _tempColor = _drawColor;
                 _drawType = DrawType.Sketch;
            _drawColor = Color.White;
            Cursor penCur = new Cursor("del.cur");
            this.Cursor = penCur;
            toolStrip1.Cursor = Cursors.Hand;
            statusStrip1.Cursor = Cursors.Arrow;
                toolStripButtoneraser.Text="停止";
            }
            else if(toolStripButtoneraser.Text=="停止"){
                _drawWidth = _tempWidth;
                _drawColor = _tempColor;
                _drawType = DrawType.Stop;
                Cursor penCur = new Cursor("pen.cur");
                this.Cursor = penCur;
                toolStrip1.Cursor = Cursors.Hand;
                statusStrip1.Cursor = Cursors.Arrow;
                toolStripButtoneraser.Text = "橡皮擦";
            }
           
        }

        private void smallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toolStripButtoneraser.Text == "橡皮擦")
            {
                _drawWidth = 10;
            }
        }

        private void midToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toolStripButtoneraser.Text == "橡皮擦")
            {
                _drawWidth = 40;
            }
        }

        private void bigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toolStripButtoneraser.Text == "橡皮擦")
            {
                _drawWidth = 80;
            }
        }

        private void hugeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toolStripButtoneraser.Text == "橡皮擦")
            {
                _drawWidth = 150;
            }
        }

        private void MenuItemZoomIn_Click(object sender, EventArgs e)
        {
            _zoomRatio = _zoomRatio * 0.9;
            panelDraw.Width = (int)(_panelDrawInitSize.Width * _zoomRatio);
            panelDraw.Height = (int)(_panelDrawInitSize.Height * _zoomRatio);
            _bufGraph.Graphics.Clear(Color.White);
            foreach (shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid,_zoomRatio);
            _bufGraph.Render(panelDraw.CreateGraphics());
        }

        private void MenuItemZoomOut_Click(object sender, EventArgs e)
        {
            _zoomRatio = _zoomRatio * 1.1;
            panelDraw.Width = (int)(_panelDrawInitSize.Width * _zoomRatio);
            panelDraw.Height = (int)(_panelDrawInitSize.Height * _zoomRatio);
            _bufGraph.Graphics.Clear(Color.White);
            foreach (shape shape in _listShape)
                shape.Draw(_bufGraph.Graphics, DashStyle.Solid, _zoomRatio);
            _bufGraph.Render(panelDraw.CreateGraphics());
        }


    }
}
