﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
namespace Pencial
{
    public enum DrawType
    {
        Stop = 0, Line = 1, Rectangle = 2, Circle = 3,Sketch = 4
    }
    public abstract class shape
    {
        public int _shapeType = 0;
        public Point _po1;
        public Point _po2;
        public int _circleR;
        public List<Point> _ptList = new List<Point>();
       
        private int _penWidth = 10;
        private Color _penColor = Color.Red;
        public int _PenWidth
        {
            get { return _penWidth; }
            set { _penWidth = value; }
        }

        public Color _PenColor
        {
            get { return _penColor; }
            set { _penColor = value; }
        }

        public abstract void Draw(Graphics g, DashStyle ds,double zoomRatio);
        public abstract void Write(BinaryWriter bw);
        public abstract void Read(BinaryReader br);

    }
    public class Line : shape
    {
        private Point _p1;
        private Point _p2;
        public Point P1
        {
            get { return _p1; }
            set { _p1 = value; }
        }

        public Point P2
        {
            get { return _p2; }
            set { _p2 = value; }
        }
        public Line()
        {

        }
        public Line(Point p1, Point p2)
        {
            _p1 = p1;
            _p2 = p2;
        }
        public override void Draw(Graphics g, DashStyle ds, double zoomRatio)
        {

            Point p1 = new Point((int)(_p1.X * zoomRatio), (int)(_p1.Y * zoomRatio));
            Point p2 = new Point((int)(_p2.X * zoomRatio), (int)(_p2.Y * zoomRatio)); 
            _po1 = p1;
            _po2 = p2;
            _shapeType = 1;
            Pen pen = new Pen(_PenColor, (int)(_PenWidth * zoomRatio));
            pen.DashStyle = ds;
            g.DrawLine(pen, p1, p2);
        }
        public override void Write(BinaryWriter bw)
        {
            bw.Write(_PenWidth);
            bw.Write(_PenColor.ToArgb());
            bw.Write(_p1.X); bw.Write(_p1.Y);
            bw.Write(_p2.X); bw.Write(_p2.Y);
        }
        public override void Read(BinaryReader br)
        {
            _PenWidth = br.ReadInt32();
            _PenColor = Color.FromArgb(br.ReadInt32());
            _p1.X = br.ReadInt32();
            _p1.Y = br.ReadInt32();
            _p2.X = br.ReadInt32();
            _p2.Y = br.ReadInt32();
        }
    }
    public class Rectangle : shape
    {
        private Point _p1;
        private Point _p2;
        public Point P1
        {
            get { return _p1; }
            set { _p1 = value; }
        }

        public Point P2
        {
            get { return _p2; }
            set { _p2 = value; }
        }
        public Rectangle()
        {
        }
        public Rectangle(Point p1, Point p2)
        {

            _p1 = p1;
            _p2 = p2;
        }
        public override void Draw(Graphics g, DashStyle ds, double zoomRatio)
        {
            Point p1 = new Point((int)(_p1.X * zoomRatio), (int)(_p1.Y * zoomRatio));
            Point p2 = new Point((int)(_p2.X * zoomRatio), (int)(_p2.Y * zoomRatio)); 
            _po1 = p1;
            _po2 = p2;
            _shapeType = 2;
            Pen pen = new Pen(_PenColor, (int)(_PenWidth * zoomRatio));
            pen.DashStyle = ds;
            Point leftTop = new Point();
            leftTop.X = (p1.X <= p2.X) ? p1.X : p2.X;
            leftTop.Y = (p1.Y <= p2.Y) ? p1.Y : p2.Y;
            g.DrawRectangle(pen, leftTop.X, leftTop.Y, Math.Abs(p2.X - p1.X), Math.Abs(p2.Y - p1.Y));

        }
        public override void Write(BinaryWriter bw)
        {
            bw.Write(_PenWidth);
            bw.Write(_PenColor.ToArgb());
            bw.Write(_p1.X); bw.Write(_p1.Y);
            bw.Write(_p2.X); bw.Write(_p2.Y);
        }
        public override void Read(BinaryReader br)
        {
            _PenWidth = br.ReadInt32();
            _PenColor = Color.FromArgb(br.ReadInt32());
            _p1.X = br.ReadInt32();
            _p1.Y = br.ReadInt32();
            _p2.X = br.ReadInt32();
            _p2.Y = br.ReadInt32();
        }

    }
    public class Circle : shape
    {
        private Point _pCenter;
        private float _r;
        private Point _pCenter2;

        public Point PCenter2
        {
            get { return _pCenter2; }
            set { _pCenter2 = value; }
        }
        public float R
        {
            get { return _r; }
            set { _r = value; }
        }
        public Point PCenter
        {
            get { return _pCenter; }
            set { _pCenter = value; }
        }
        public Circle()
        {
        }
        public Circle(Point pCenter, float r)
        {
            _pCenter = pCenter;
            _r = r;
            _pCenter2 = PCenter2;
        }
        public override void Draw(Graphics g, DashStyle ds, double zoomRatio)
        {
            Point pCenter = new Point((int)(_pCenter.X * zoomRatio), (int)(_pCenter.Y * zoomRatio));
            Point pCenter2 = new Point((int)(_pCenter2.X * zoomRatio), (int)(_pCenter2.Y * zoomRatio));

            float R = (float)(_r * zoomRatio);
;
            _shapeType = 3;
            Point _center=new Point();
            Pen pen = new Pen(_PenColor, (int)(_PenWidth*zoomRatio));
            Pen pe = new Pen(_PenColor, 10);
            Point leftTop = new Point();
            leftTop.X = (int)((pCenter.X + pCenter2.X) / 2 - R);
            leftTop.Y = (int)((pCenter.Y + pCenter2.Y) / 2 - R);
            _center.X = (int)((pCenter.X + pCenter2.X) / 2);
            _center.Y = (int)((pCenter.Y + pCenter2.Y) / 2);
            _po1 = _center;
            _circleR = (int)R;
            pen.DashStyle = ds;
            g.DrawEllipse (pen,leftTop.X,leftTop.Y, 2 *R, 2 * R);
            g.DrawEllipse( pe, leftTop.X+R, leftTop.Y+R, 2, 2 );
        }
        public override void Write(BinaryWriter bw)
        {
            bw.Write(_PenWidth);
            bw.Write(_PenColor.ToArgb());
            bw.Write(_pCenter.X); bw.Write(_pCenter.Y);
            bw.Write(_pCenter2.X); bw.Write(_pCenter2.Y);
            bw.Write(_r); 
        }
        public override void Read(BinaryReader br)
        {
            _PenWidth = br.ReadInt32();
            _PenColor = Color.FromArgb(br.ReadInt32());
            _pCenter.X = br.ReadInt32();
            _pCenter.Y = br.ReadInt32();
            _pCenter2.X = br.ReadInt32();
            _pCenter2.Y = br.ReadInt32();
            _r = br.ReadSingle();
        }

    }

    public class Sketch : shape
    {
        private List<Point> _pointList = new List<Point>();

        public List<Point> PointList
        {
            get { return _pointList; }
            set { _pointList = value; }
        }

        public Sketch()
        {

        }

        public override void Draw(Graphics g, DashStyle ds, double zoomRatio)
        {
            _shapeType = 4;
            Pen pen = new Pen(_PenColor, (int)(_PenWidth * zoomRatio));
            pen.DashStyle = ds;
            pen.StartCap = LineCap.Round;
            pen.EndCap = LineCap.Round;
            for (int i = 1; i < _pointList.Count; i++) {

                Point p1 = new Point((int)(_pointList[i - 1].X * zoomRatio), (int)(_pointList[i - 1].Y * zoomRatio));
                Point p2 = new Point((int)(_pointList[i].X * zoomRatio), (int)(_pointList[i].Y * zoomRatio)); 

                g.DrawLine(pen, p1, p2);
                _ptList.Add(p1);
            }
            _ptList.Add(_pointList[_pointList.Count-1]);
                
        }
        public override void Write(BinaryWriter bw)
        {
            bw.Write(_PenWidth);
            bw.Write(_PenColor.ToArgb());
            bw.Write(_pointList.Count());
            foreach (Point tempPoint in _pointList)
            {
                bw.Write(tempPoint.X);
                bw.Write(tempPoint.Y);
            }
        }
        public override void Read(BinaryReader br)
        {
            _pointList.Clear();
            _PenWidth = br.ReadInt32();
            _PenColor = Color.FromArgb(br.ReadInt32());
            int pointCount = br.ReadInt32();
            for (int i = 0; i < pointCount; i++)
            {
                int x = br.ReadInt32();
                int y = br.ReadInt32();
                Point point = new Point(x, y);
                _pointList.Add(point);
            }

        }
    }
}
