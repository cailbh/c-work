﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing
namespace TankWar
{
    public enum GameState
    {
        Close =1,Open = 2, Pause
    }

    public enum Direction
    {
        Up = 1,Down = 2, Right = 3, Left = 4
    }

    public enum Side
    {
        Me = 1, Enemy = 2
    }
    class Tank
    {
        #region 私有字段
        //坦克坐标
        private Point _position = new Point(200,200);
        //坦克运动方向
        private Direction _direction = Direction.Up;
        //步长
        private int _step = 5;
        //大小
        private int _size = 30;
        //敌我标志
        Side _side;
        //坦克位图数组
        private Bitmap[] _tankBmp = new Bitmap[8];
        //当前坦克位图
        private Bitmap _nowTankBmp = new Bitmap(30,30);
        //坦克位图轮换标志
        private bool _tankBmpchange = true;
        #endregion

        #region 公有字段
        //坦克坐标
        public Point Position
        {
          get { return _position; }
          set { _position = value; }
        }
        //坦克运动方向
        public Direction Direction
        {
          get { return _direction; }
          set { _direction = value; }
        }
        //步长
        public int Step
        {
          get { return _step; }
          set { _step = value; }
        }
        //大小
        public int Size
        {
          get { return _size; }
          set { _size = value; }
        }
        //敌我标志
        public Side Side
        {
          get { return _side; }
          set { _side = value; }
        }
        //坦克位图数组
        #endregion

        //构造方法
        public Tank(Side side)
        {
            //敌我标志
            _side = side;
            if(side == Side.Me)
            {
                //装载
                _tankBmp[0] = new Bitmap("MyTankUp1.gif");
                _tankBmp[1] = new Bitmap("MyTankUp2.gif");
                _tankBmp[2] = new Bitmap("MyTankDown1.gif");
                _tankBmp[3] = new Bitmap("MyTankDown2.gif");
                _tankBmp[4] = new Bitmap("MyTankLeft1.gif");
                _tankBmp[5] = new Bitmap("MyTankLeft2.gif");
                _tankBmp[6] = new Bitmap("MyTankRight1.gif");
                _tankBmp[7] = new Bitmap("MyTankRight2.gif");
            }
            else
            {
                _tankBmp[0] = new Bitmap("EnemyTankUp1.gif");
                _tankBmp[1] = new Bitmap("EnemyTankUp2.gif");
                _tankBmp[2] = new Bitmap("EnemyTankDown1.gif");
                _tankBmp[3] = new Bitmap("EnemyTankDown2.gif");
                _tankBmp[4] = new Bitmap("EnemyTankLeft1.gif");
                _tankBmp[5] = new Bitmap("EnemyTankLeft2.gif");
                _tankBmp[6] = new Bitmap("EnemyTankRight1.gif");
                _tankBmp[7] = new Bitmap("EnemyTankRight2.gif");
            }
            //设置坦克位图透明色
            for (int i = 0; i <= 7; i++)
                _tankBmp[i].MakeTransparent(Color.Black);
            //向上运动
            _nowTankBmp = _tankBmp[0];
        }
        //运动方法
        public void Move(Direction direction)
        {
            //保存运动方向
            _direction = direction;
            //向上
            if(direction == Direction.Up)
            {
                //运动后的位置
                _position.Y = _position.Y - _step;
                //当前位图
                if(_tankBmpchange == true)
                    _nowTankBmp = _tankBmp[0];
                else
                    _nowTankBmp = _tankBmp[1];
            }
            //下
            else if(direction == Direction.Down)
            {
                //运动后的位置
                _position.Y = _position.Y - _step;
                //当前位图
                if(_tankBmpchange == true)
                    _nowTankBmp = _tankBmp[2];
                else
                    _nowTankBmp = _tankBmp[3];
            } 
            else if(direction == Direction.Left)
                {
                    //运动后的位置
                    _position.Y = _position.Y - _step;
                    //当前位图
                    if(_tankBmpchange == true)
                        _nowTankBmp = _tankBmp[4];
                    else
                        _nowTankBmp = _tankBmp[5];
                }
            else if(direction == Direction.Right)
                {
                    //运动后的位置
                    _position.Y = _position.Y - _step;
                    //当前位图
                    if(_tankBmpchange == true)
                        _nowTankBmp = _tankBmp[6];
                    else
                        _nowTankBmp = _tankBmp[7];
                }
            _tankBmpchange = !_tankBmpchange;
        }
        public void DrawMe(Graphics g)
        {
            //绘制坦克
            g.DrawImage(_nowTankBmp, _position);
        }

    }
}