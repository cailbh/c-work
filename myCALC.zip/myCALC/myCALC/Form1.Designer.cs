﻿namespace myCALC
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.buttonNUM1 = new System.Windows.Forms.Button();
            this.buttonNUM2 = new System.Windows.Forms.Button();
            this.buttonNUM6 = new System.Windows.Forms.Button();
            this.buttonNUM8 = new System.Windows.Forms.Button();
            this.buttonNUM9 = new System.Windows.Forms.Button();
            this.buttonNUM3 = new System.Windows.Forms.Button();
            this.buttonNUM7 = new System.Windows.Forms.Button();
            this.buttonNUM4 = new System.Windows.Forms.Button();
            this.buttonNUM5 = new System.Windows.Forms.Button();
            this.buttonNUM0 = new System.Windows.Forms.Button();
            this.buttonDivide = new System.Windows.Forms.Button();
            this.buttonMultiply = new System.Windows.Forms.Button();
            this.buttonSubtract = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonEqual = new System.Windows.Forms.Button();
            this.buttonDot = new System.Windows.Forms.Button();
            this.buttonBackSpace = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonSign = new System.Windows.Forms.Button();
            this.radioButtonbinary = new System.Windows.Forms.RadioButton();
            this.radioButtonoctal = new System.Windows.Forms.RadioButton();
            this.radioButtondecimal = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // textBoxResult
            // 
            this.textBoxResult.Font = new System.Drawing.Font("微软雅黑", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxResult.Location = new System.Drawing.Point(35, 21);
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.ReadOnly = true;
            this.textBoxResult.Size = new System.Drawing.Size(337, 71);
            this.textBoxResult.TabIndex = 0;
            this.textBoxResult.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxResult_KeyPress);
            // 
            // buttonNUM1
            // 
            this.buttonNUM1.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM1.Location = new System.Drawing.Point(35, 134);
            this.buttonNUM1.Name = "buttonNUM1";
            this.buttonNUM1.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM1.TabIndex = 1;
            this.buttonNUM1.TabStop = false;
            this.buttonNUM1.Text = "1";
            this.buttonNUM1.UseVisualStyleBackColor = true;
            this.buttonNUM1.Click += new System.EventHandler(this.buttonNUM1_Click);
            // 
            // buttonNUM2
            // 
            this.buttonNUM2.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM2.Location = new System.Drawing.Point(125, 134);
            this.buttonNUM2.Name = "buttonNUM2";
            this.buttonNUM2.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM2.TabIndex = 2;
            this.buttonNUM2.TabStop = false;
            this.buttonNUM2.Text = "2";
            this.buttonNUM2.UseVisualStyleBackColor = true;
            this.buttonNUM2.Click += new System.EventHandler(this.buttonNUM2_Click);
            // 
            // buttonNUM6
            // 
            this.buttonNUM6.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM6.Location = new System.Drawing.Point(215, 217);
            this.buttonNUM6.Name = "buttonNUM6";
            this.buttonNUM6.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM6.TabIndex = 3;
            this.buttonNUM6.TabStop = false;
            this.buttonNUM6.Text = "6";
            this.buttonNUM6.UseVisualStyleBackColor = true;
            this.buttonNUM6.Click += new System.EventHandler(this.buttonNUM6_Click);
            // 
            // buttonNUM8
            // 
            this.buttonNUM8.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM8.Location = new System.Drawing.Point(125, 299);
            this.buttonNUM8.Name = "buttonNUM8";
            this.buttonNUM8.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM8.TabIndex = 4;
            this.buttonNUM8.TabStop = false;
            this.buttonNUM8.Text = "8";
            this.buttonNUM8.UseVisualStyleBackColor = true;
            this.buttonNUM8.Click += new System.EventHandler(this.buttonNUM8_Click);
            // 
            // buttonNUM9
            // 
            this.buttonNUM9.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM9.Location = new System.Drawing.Point(215, 300);
            this.buttonNUM9.Name = "buttonNUM9";
            this.buttonNUM9.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM9.TabIndex = 5;
            this.buttonNUM9.TabStop = false;
            this.buttonNUM9.Text = "9";
            this.buttonNUM9.UseVisualStyleBackColor = true;
            this.buttonNUM9.Click += new System.EventHandler(this.buttonNUM9_Click);
            // 
            // buttonNUM3
            // 
            this.buttonNUM3.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM3.Location = new System.Drawing.Point(215, 134);
            this.buttonNUM3.Name = "buttonNUM3";
            this.buttonNUM3.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM3.TabIndex = 6;
            this.buttonNUM3.TabStop = false;
            this.buttonNUM3.Text = "3";
            this.buttonNUM3.UseVisualStyleBackColor = true;
            this.buttonNUM3.Click += new System.EventHandler(this.buttonNUM3_Click);
            // 
            // buttonNUM7
            // 
            this.buttonNUM7.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM7.Location = new System.Drawing.Point(35, 299);
            this.buttonNUM7.Name = "buttonNUM7";
            this.buttonNUM7.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM7.TabIndex = 7;
            this.buttonNUM7.TabStop = false;
            this.buttonNUM7.Text = "7";
            this.buttonNUM7.UseVisualStyleBackColor = true;
            this.buttonNUM7.Click += new System.EventHandler(this.buttonNUM7_Click);
            // 
            // buttonNUM4
            // 
            this.buttonNUM4.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM4.Location = new System.Drawing.Point(35, 217);
            this.buttonNUM4.Name = "buttonNUM4";
            this.buttonNUM4.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM4.TabIndex = 8;
            this.buttonNUM4.TabStop = false;
            this.buttonNUM4.Text = "4";
            this.buttonNUM4.UseVisualStyleBackColor = true;
            this.buttonNUM4.Click += new System.EventHandler(this.buttonNUM4_Click);
            // 
            // buttonNUM5
            // 
            this.buttonNUM5.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM5.Location = new System.Drawing.Point(125, 217);
            this.buttonNUM5.Name = "buttonNUM5";
            this.buttonNUM5.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM5.TabIndex = 9;
            this.buttonNUM5.TabStop = false;
            this.buttonNUM5.Text = "5";
            this.buttonNUM5.UseVisualStyleBackColor = true;
            this.buttonNUM5.Click += new System.EventHandler(this.buttonNUM5_Click);
            // 
            // buttonNUM0
            // 
            this.buttonNUM0.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonNUM0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonNUM0.Location = new System.Drawing.Point(35, 382);
            this.buttonNUM0.Name = "buttonNUM0";
            this.buttonNUM0.Size = new System.Drawing.Size(67, 77);
            this.buttonNUM0.TabIndex = 10;
            this.buttonNUM0.TabStop = false;
            this.buttonNUM0.Text = "0";
            this.buttonNUM0.UseVisualStyleBackColor = true;
            this.buttonNUM0.Click += new System.EventHandler(this.buttonNUM0_Click);
            // 
            // buttonDivide
            // 
            this.buttonDivide.Font = new System.Drawing.Font("幼圆", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonDivide.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonDivide.Location = new System.Drawing.Point(305, 383);
            this.buttonDivide.Name = "buttonDivide";
            this.buttonDivide.Size = new System.Drawing.Size(67, 77);
            this.buttonDivide.TabIndex = 11;
            this.buttonDivide.TabStop = false;
            this.buttonDivide.Text = "/";
            this.buttonDivide.UseVisualStyleBackColor = true;
            // 
            // buttonMultiply
            // 
            this.buttonMultiply.Font = new System.Drawing.Font("幼圆", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonMultiply.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonMultiply.Location = new System.Drawing.Point(305, 300);
            this.buttonMultiply.Name = "buttonMultiply";
            this.buttonMultiply.Size = new System.Drawing.Size(67, 77);
            this.buttonMultiply.TabIndex = 12;
            this.buttonMultiply.TabStop = false;
            this.buttonMultiply.Text = "*";
            this.buttonMultiply.UseVisualStyleBackColor = true;
            this.buttonMultiply.Click += new System.EventHandler(this.buttonMultiply_Click);
            // 
            // buttonSubtract
            // 
            this.buttonSubtract.Font = new System.Drawing.Font("幼圆", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonSubtract.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonSubtract.Location = new System.Drawing.Point(305, 217);
            this.buttonSubtract.Name = "buttonSubtract";
            this.buttonSubtract.Size = new System.Drawing.Size(67, 77);
            this.buttonSubtract.TabIndex = 13;
            this.buttonSubtract.TabStop = false;
            this.buttonSubtract.Text = "-";
            this.buttonSubtract.UseVisualStyleBackColor = true;
            this.buttonSubtract.Click += new System.EventHandler(this.buttonSubtract_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Font = new System.Drawing.Font("幼圆", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonAdd.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonAdd.Location = new System.Drawing.Point(305, 134);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(67, 77);
            this.buttonAdd.TabIndex = 14;
            this.buttonAdd.TabStop = false;
            this.buttonAdd.Text = "+";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonEqual
            // 
            this.buttonEqual.Font = new System.Drawing.Font("幼圆", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonEqual.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.buttonEqual.Location = new System.Drawing.Point(305, 466);
            this.buttonEqual.Name = "buttonEqual";
            this.buttonEqual.Size = new System.Drawing.Size(67, 77);
            this.buttonEqual.TabIndex = 15;
            this.buttonEqual.TabStop = false;
            this.buttonEqual.Text = "=";
            this.buttonEqual.UseVisualStyleBackColor = true;
            this.buttonEqual.Click += new System.EventHandler(this.buttonEqual_Click);
            // 
            // buttonDot
            // 
            this.buttonDot.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonDot.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonDot.Location = new System.Drawing.Point(125, 382);
            this.buttonDot.Name = "buttonDot";
            this.buttonDot.Size = new System.Drawing.Size(67, 77);
            this.buttonDot.TabIndex = 17;
            this.buttonDot.TabStop = false;
            this.buttonDot.Text = ".";
            this.buttonDot.UseVisualStyleBackColor = true;
            this.buttonDot.Click += new System.EventHandler(this.buttonDot_Click);
            // 
            // buttonBackSpace
            // 
            this.buttonBackSpace.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonBackSpace.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonBackSpace.Location = new System.Drawing.Point(215, 382);
            this.buttonBackSpace.Name = "buttonBackSpace";
            this.buttonBackSpace.Size = new System.Drawing.Size(67, 77);
            this.buttonBackSpace.TabIndex = 18;
            this.buttonBackSpace.TabStop = false;
            this.buttonBackSpace.Text = "<-";
            this.buttonBackSpace.UseVisualStyleBackColor = true;
            this.buttonBackSpace.Click += new System.EventHandler(this.buttonBackSpace_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonClear.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonClear.Location = new System.Drawing.Point(35, 466);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(155, 77);
            this.buttonClear.TabIndex = 19;
            this.buttonClear.TabStop = false;
            this.buttonClear.Text = "C";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonSign
            // 
            this.buttonSign.Font = new System.Drawing.Font("幼圆", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.buttonSign.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonSign.Location = new System.Drawing.Point(214, 466);
            this.buttonSign.Name = "buttonSign";
            this.buttonSign.Size = new System.Drawing.Size(67, 77);
            this.buttonSign.TabIndex = 20;
            this.buttonSign.TabStop = false;
            this.buttonSign.Text = "+/-";
            this.buttonSign.UseVisualStyleBackColor = true;
            this.buttonSign.Click += new System.EventHandler(this.buttonSign_Click);
            // 
            // radioButtonbinary
            // 
            this.radioButtonbinary.AutoSize = true;
            this.radioButtonbinary.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.radioButtonbinary.Location = new System.Drawing.Point(34, 98);
            this.radioButtonbinary.Name = "radioButtonbinary";
            this.radioButtonbinary.Size = new System.Drawing.Size(103, 28);
            this.radioButtonbinary.TabIndex = 21;
            this.radioButtonbinary.Text = "二进制";
            this.radioButtonbinary.UseVisualStyleBackColor = true;
            this.radioButtonbinary.Click += new System.EventHandler(this.radioButtonbinary_Click);
            // 
            // radioButtonoctal
            // 
            this.radioButtonoctal.AutoSize = true;
            this.radioButtonoctal.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.radioButtonoctal.Location = new System.Drawing.Point(268, 98);
            this.radioButtonoctal.Name = "radioButtonoctal";
            this.radioButtonoctal.Size = new System.Drawing.Size(103, 28);
            this.radioButtonoctal.TabIndex = 22;
            this.radioButtonoctal.Text = "八进制";
            this.radioButtonoctal.UseVisualStyleBackColor = true;
            this.radioButtonoctal.Click += new System.EventHandler(this.radioButtonoctal_Click);
            // 
            // radioButtondecimal
            // 
            this.radioButtondecimal.AutoSize = true;
            this.radioButtondecimal.Checked = true;
            this.radioButtondecimal.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.radioButtondecimal.Location = new System.Drawing.Point(151, 98);
            this.radioButtondecimal.Name = "radioButtondecimal";
            this.radioButtondecimal.Size = new System.Drawing.Size(103, 28);
            this.radioButtondecimal.TabIndex = 23;
            this.radioButtondecimal.TabStop = true;
            this.radioButtondecimal.Text = "十进制";
            this.radioButtondecimal.UseVisualStyleBackColor = true;
            this.radioButtondecimal.Click += new System.EventHandler(this.radioButtondecimal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 551);
            this.Controls.Add(this.radioButtondecimal);
            this.Controls.Add(this.radioButtonoctal);
            this.Controls.Add(this.radioButtonbinary);
            this.Controls.Add(this.buttonSign);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonBackSpace);
            this.Controls.Add(this.buttonDot);
            this.Controls.Add(this.buttonEqual);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonSubtract);
            this.Controls.Add(this.buttonMultiply);
            this.Controls.Add(this.buttonDivide);
            this.Controls.Add(this.buttonNUM0);
            this.Controls.Add(this.buttonNUM5);
            this.Controls.Add(this.buttonNUM4);
            this.Controls.Add(this.buttonNUM7);
            this.Controls.Add(this.buttonNUM3);
            this.Controls.Add(this.buttonNUM9);
            this.Controls.Add(this.buttonNUM8);
            this.Controls.Add(this.buttonNUM6);
            this.Controls.Add(this.buttonNUM2);
            this.Controls.Add(this.buttonNUM1);
            this.Controls.Add(this.textBoxResult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "我的计算器";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.Button buttonNUM1;
        private System.Windows.Forms.Button buttonNUM2;
        private System.Windows.Forms.Button buttonNUM6;
        private System.Windows.Forms.Button buttonNUM8;
        private System.Windows.Forms.Button buttonNUM9;
        private System.Windows.Forms.Button buttonNUM3;
        private System.Windows.Forms.Button buttonNUM7;
        private System.Windows.Forms.Button buttonNUM4;
        private System.Windows.Forms.Button buttonNUM5;
        private System.Windows.Forms.Button buttonNUM0;
        private System.Windows.Forms.Button buttonDivide;
        private System.Windows.Forms.Button buttonMultiply;
        private System.Windows.Forms.Button buttonSubtract;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonEqual;
        private System.Windows.Forms.Button buttonDot;
        private System.Windows.Forms.Button buttonBackSpace;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonSign;
        private System.Windows.Forms.RadioButton radioButtonbinary;
        private System.Windows.Forms.RadioButton radioButtonoctal;
        private System.Windows.Forms.RadioButton radioButtondecimal;
    }
}

