﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace myCALC
{
    
    public partial class Form1 : Form
    {
        private decimal _num1 = 0, _num2 = 0, _result = 0;
        private string _operator = "";
        private int _operatorCount = 0;
        private bool _firstNumberFlag = false;
        private int _jageSystem=10;
        private string _temp;
        public string AddBetweenBinary(string x, string y)
        {
            int intSum = Convert.ToInt32(x, 2) + Convert.ToInt32(y, 2);
            return Convert.ToString(intSum, 2);
        }

        /// 从二进制转换成其他进制
        private string ConvertGenericBinaryFromBinary(string input, byte toType)
        {
            switch (toType)
            {
                case 8:
                    //先转换成十进制然后转八进制
                    input = Convert.ToString(Convert.ToInt32(input, 2), 8);
                    break;
                case 10:
                    input = Convert.ToInt32(input, 2).ToString();
                    break;
                case 16:
                    input = Convert.ToString(Convert.ToInt32(input, 2), 16);
                    break;
                default:
                    break;
            }
            return input;
        }
        /// 从八进制转换成其他进制
        private string ConvertGenericBinaryFromOctal(string input, byte toType)
        {
            switch (toType)
            {
                case 2:
                    input = Convert.ToString(Convert.ToInt32(input, 8), 2);
                    break;
                case 10:
                    input = Convert.ToInt32(input, 8).ToString();
                    break;
                case 16:
                    input = Convert.ToString(Convert.ToInt32(input, 8), 16);
                    break;
                default:
                    break;
            }
            return input;
        }
        /// 从十进制转换成其他进制
        private string ConvertGenericBinaryFromDecimal(string input, int toType)
        {
            string output = "";
            int intInput = Convert.ToInt32(input);
            switch (toType)
            {
                case 2:
                    output = Convert.ToString(intInput, 2);
                    break;
                case 8:
                    output = Convert.ToString(intInput, 8);
                    break;
                case 16:
                    output = Convert.ToString(intInput, 16);
                    break;
                default:
                    output = input;
                    break;
            }
            return output;
        }
        public string ConvertGenericBinary(string input, byte fromType, byte toType)
        {
            string output = input;
            switch (fromType)
            {
                case 2:
                    output = ConvertGenericBinaryFromBinary(input, toType);
                    break;
                case 8:
                    output = ConvertGenericBinaryFromOctal(input, toType);
                    break;
                case 10:
                    output = ConvertGenericBinaryFromDecimal(input, toType);
                    break;
                default:
                    break;
            }
            return output;
        }     
        public Form1()
        {
            InitializeComponent();
        }

     

        private void buttonNUM1_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "1";
                _firstNumberFlag = false;
            }
            else
            textBoxResult.Text = textBoxResult.Text + "1";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM2_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "2";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "2";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM3_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "3";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "3";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM4_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "4";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "4";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM5_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "5";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "5";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM6_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "6";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "6";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM7_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "7";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "7";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM8_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "8";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "8";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM9_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "9";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "9";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonNUM0_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = "0";
                _firstNumberFlag = false;
            }
            else
                textBoxResult.Text = textBoxResult.Text + "0";
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            _firstNumberFlag = true;
            _operatorCount = 1 + _operatorCount;
            if (_operatorCount == 1)
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num1 = Convert.ToDecimal(textBoxResult.Text);
                }
                _operator = "+";
                textBoxResult.Text = "";
            }
            else 
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num2 = Convert.ToDecimal(textBoxResult.Text);
                }
                if (_operator == "+")
                    _num1 = _num1 + _num2;
                else if (_operator == "-")
                    _num1 = _num1 - _num2;
                else if (_operator == "*")
                    _num1 = _num1 * _num2;
                else if (_operator == "/")
                    _num1 = _num1 / _num2;
                _operator = "+";

                if (_jageSystem == 2)
                {
                    //_result从10进制转换为2
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 2);
                }
                else if (_jageSystem == 8)
                {
                    //_result从10转换为8
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 8);
                }
                else
                {
                    textBoxResult.Text = _num1.ToString();
                }

                
            }
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
            
        }

        private void buttonSubtract_Click(object sender, EventArgs e)
        {
            _firstNumberFlag = true;
            _operatorCount = 1 + _operatorCount;
            if (_operatorCount == 1)
            {

                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num1 = Convert.ToDecimal(textBoxResult.Text);
                }
                _operator = "-";
                textBoxResult.Text = "";
            }
            else
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num2 = Convert.ToDecimal(textBoxResult.Text);
                }
                if (_operator == "+")
                    _num1 = _num1 + _num2;
                else if (_operator == "-")
                    _num1 = _num1 - _num2;
                else if (_operator == "*")
                    _num1 = _num1 * _num2;
                else if (_operator == "/")
                    _num1 = _num1 / _num2;
                _operator = "+";
                if (_jageSystem == 2)
                {
                    //_result从10进制转换为2
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 2);
                }
                else if (_jageSystem == 8)
                {
                    //_result从10转换为8
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 8);
                }
                else
                {
                    textBoxResult.Text = _num1.ToString();
                }

          
            }
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonMultiply_Click(object sender, EventArgs e)
        {
            _firstNumberFlag = true;
            _operatorCount = 1 + _operatorCount;
            if (_operatorCount == 1)
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num1 = Convert.ToDecimal(textBoxResult.Text);
                }
                _operator = "*";
                textBoxResult.Text = "";
            }
            else
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num2 = Convert.ToDecimal(textBoxResult.Text);
                }
                if (_operator == "+")
                    _num1 = _num1 + _num2;
                else if (_operator == "-")
                    _num1 = _num1 - _num2;
                else if (_operator == "*")
                    _num1 = _num1 * _num2;
                else if (_operator == "/")
                    _num1 = _num1 / _num2;
                _operator = "+";
                if (_jageSystem == 2)
                {
                    //_result从10进制转换为2
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 2);
                }
                else if (_jageSystem == 8)
                {
                    //_result从10转换为8
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 8);
                }
                else
                {
                    textBoxResult.Text = _num1.ToString();
                }

       
            }
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonDivide_Click(object sender, EventArgs e)
        {
            _firstNumberFlag = true;
            _operatorCount = 1 + _operatorCount;
            if (_operatorCount == 1)
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num1 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num1 = Convert.ToDecimal(textBoxResult.Text);
                }
                _operator = "/";
                textBoxResult.Text = "";
            }
            else
            {
                if (_jageSystem == 2)
                {
                    //-num2从2进制转换为10
                    _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else if (_jageSystem == 8)
                {
                    //_num2从8转换为10
                    _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                    _num2 = Convert.ToDecimal(_temp);
                }
                else
                {
                    _num2 = Convert.ToDecimal(textBoxResult.Text);
                }
                if (_operator == "+")
                    _num1 = _num1 + _num2;
                else if (_operator == "-")
                    _num1 = _num1 - _num2;
                else if (_operator == "*")
                    _num1 = _num1 * _num2;
                else if (_operator == "/")
                    _num1 = _num1 / _num2;
                _operator = "+";
                if (_jageSystem == 2)
                {
                    //_result从10进制转换为2
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 2);
                }
                else if (_jageSystem == 8)
                {
                    //_result从10转换为8
                    textBoxResult.Text = ConvertGenericBinaryFromDecimal(_num1.ToString(), 8);
                }
                else
                {
                    textBoxResult.Text = _num1.ToString();
                }

            }
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonEqual_Click(object sender, EventArgs e)
        {
            if (_jageSystem == 2){ 
            //-num2从2进制转换为10
                _temp = ConvertGenericBinaryFromBinary(textBoxResult.Text, 10);
                _num2 = Convert.ToDecimal(_temp);
            }
            else if(_jageSystem==8){
            //_num2从8转换为10
                _temp = ConvertGenericBinaryFromOctal(textBoxResult.Text, 10);
                _num2 = Convert.ToDecimal(_temp);
            }
            else{
            _num2 = Convert.ToDecimal(textBoxResult.Text);
            }
            if (_operator == "+")
                _result = _num1 + _num2;
            else if (_operator == "-")
                _result = _num1 - _num2;
            else if (_operator == "*")
                _result = _num1 * _num2;
            else if (_operator == "/")
                _result = _num1 / _num2;
            if (_jageSystem == 2)
            {
                //_result从10进制转换为2
                textBoxResult.Text = ConvertGenericBinaryFromDecimal(_result.ToString(), 2);
            }
            else if (_jageSystem == 8)
            {
                //_result从10转换为8
                textBoxResult.Text = ConvertGenericBinaryFromDecimal(_result.ToString(), 8);
            }
            else
            {
                textBoxResult.Text = _result.ToString();
            }
            _operatorCount = 0;
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonDot_Click(object sender, EventArgs e)
        {
            if (_firstNumberFlag == true)
            {
                textBoxResult.Text = ".";
                _firstNumberFlag = false;
            }
            else
            {
                if(textBoxResult.Text.IndexOf('.')==-1)
                textBoxResult.Text = textBoxResult.Text + ".";
            }
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxResult.Text =  "";
            _num1 = 0;
            _num2 = 0;
            _result = 0;
            _operator = "";
            _firstNumberFlag = false;
            _operatorCount = 0;
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonBackSpace_Click(object sender, EventArgs e)
        {
            if (textBoxResult.Text.Length > 0)
                textBoxResult.Text = textBoxResult.Text.Substring(0, textBoxResult.Text.Length - 1);
            textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);
        }

        private void buttonSign_Click(object sender, EventArgs e)
        {
            if (textBoxResult.Text.Length >= 1) 
            {
                string firstChar = textBoxResult.Text.Substring(0, 1);
                if (firstChar == "-")
                    textBoxResult.Text = "+" + textBoxResult.Text.Substring(1, textBoxResult.Text.Length - 1);
                else if (firstChar == "+")
                    textBoxResult.Text = "-" + textBoxResult.Text.Substring(1, textBoxResult.Text.Length - 1);
                else
                    textBoxResult.Text = "-" + textBoxResult.Text;

            } textBoxResult.Focus();
            textBoxResult.Select(textBoxResult.Text.Length, 0);

        }
        //keyboard
        private void textBoxResult_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar=='0')
                buttonNUM0_Click(sender,e);
            else if (e.KeyChar == '1')
                buttonNUM1_Click(sender, e);
            else if (e.KeyChar == '2')
                buttonNUM2_Click(sender, e);
            else if (e.KeyChar == '3')
                buttonNUM3_Click(sender, e);
            else if (e.KeyChar == '4')
                buttonNUM4_Click(sender, e);
            else if (e.KeyChar == '5')
                buttonNUM5_Click(sender, e);
            else if (e.KeyChar == '6')
                buttonNUM6_Click(sender, e);
            else if (e.KeyChar == '7')
                buttonNUM7_Click(sender, e);
            else if (e.KeyChar == '8')
                buttonNUM8_Click(sender, e);
            else if (e.KeyChar == '9')
                buttonNUM9_Click(sender, e);
            else if (e.KeyChar == '+')
                buttonAdd_Click(sender, e);
            else if (e.KeyChar == '-')
                buttonSubtract_Click(sender, e);
            else if (e.KeyChar == '*')
                buttonMultiply_Click(sender, e);
            else if (e.KeyChar == '/')
                buttonDivide_Click(sender, e);
            else if (e.KeyChar == '.')
                buttonDot_Click(sender, e);
            else if (e.KeyChar == '=')
                buttonEqual_Click(sender, e);
            else if (e.KeyChar == 8)
                buttonBackSpace_Click(sender, e);
            textBoxResult.Select(textBoxResult.Text.Length, 0);

        }
        //2
        private void radioButtonbinary_Click(object sender, EventArgs e)
        {
            //2
            if (textBoxResult.Text.Length != 0)
            {
            if(_jageSystem==10)
                textBoxResult.Text = Convert.ToString(Convert.ToInt64(textBoxResult.Text), 2);
            else if(_jageSystem==8)
                textBoxResult.Text = Convert.ToString(Convert.ToInt64(textBoxResult.Text, 8), 2);
            }
            buttonNUM2.Enabled = false;
            buttonNUM3.Enabled = false;
            buttonNUM4.Enabled = false;
            buttonNUM5.Enabled = false;
            buttonNUM6.Enabled = false;
            buttonNUM7.Enabled = false;
            buttonNUM8.Enabled = false;
            buttonNUM9.Enabled = false;
            buttonDot.Enabled = false;
            _jageSystem = 2;
        }
        //10
        private void radioButtondecimal_Click(object sender, EventArgs e)
        {
            //10
            if(textBoxResult.Text.Length!=0){
            if(_jageSystem==2)
                textBoxResult.Text = Convert.ToInt64(textBoxResult.Text, 2).ToString();
            else if(_jageSystem==8)
                textBoxResult.Text = Convert.ToInt64(textBoxResult.Text, 8).ToString();
           
            }
                buttonNUM1.Enabled = true;
            buttonNUM2.Enabled = true;
            buttonNUM3.Enabled = true;
            buttonNUM4.Enabled = true;
            buttonNUM5.Enabled = true;
            buttonNUM6.Enabled = true;
            buttonNUM7.Enabled = true;
            buttonNUM8.Enabled = true;
            buttonNUM9.Enabled = true;
            buttonNUM0.Enabled = true;
            buttonDot.Enabled = true;
            _jageSystem = 10;
        }
        //8
        private void radioButtonoctal_Click(object sender, EventArgs e)
        {
            //8
            if(textBoxResult.Text.Length!=0){
            if(_jageSystem==10)
                textBoxResult.Text = Convert.ToString(Convert.ToInt64(textBoxResult.Text), 8);
            else if(_jageSystem==2)
                textBoxResult.Text = Convert.ToString(Convert.ToInt32(textBoxResult.Text, 2), 8);
            }
            buttonNUM1.Enabled = true;
            buttonNUM2.Enabled = true;
            buttonNUM3.Enabled = true;
            buttonNUM4.Enabled = true;
            buttonNUM5.Enabled = true;
            buttonNUM6.Enabled = true;
            buttonNUM7.Enabled = true;
            buttonNUM9.Enabled = false;
            buttonNUM8.Enabled = false;
            buttonDot.Enabled = false;
            _jageSystem = 8;

        }





       

   

        
    }
}
